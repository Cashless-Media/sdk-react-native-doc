/**
 * MyCashless SDK
 * Main entry point for the SDK
 * Handles initialization and provides access to all services
 */
import { StorageAdapter } from '../storage/SecureStorage';
import { DatabaseAdapter } from '../storage/DatabaseManager';
import { SyncService } from '../sync/SyncService';
import { AuthService } from '../services/AuthService';
import { WalletService } from '../services/WalletService';
import { PaymentService } from '../services/PaymentService';
import type { SDKConfig, Event, EventConnection, ProcessQRResult, SyncResult, SyncStatusCallback } from './types';
/**
 * SDK initialization state
 */
export interface SDKState {
    initialized: boolean;
    eventSet: boolean;
    production: boolean;
}
/**
 * MyCashlessSDK class
 * Singleton for SDK management
 */
export declare class MyCashlessSDK {
    private static instance;
    private config;
    private state;
    private _currentEvent;
    private _authService;
    private _walletService;
    private _paymentService;
    private _syncService;
    private _onSyncStatusCallback;
    private constructor();
    /**
     * Get singleton instance
     */
    static getInstance(): MyCashlessSDK;
    /**
     * Initialize the SDK
     * Must be called before using any SDK functionality
     *
     * @example
     * ```typescript
     * import { MyCashlessSDK } from '@mycashless/react-native-sdk';
     *
     * // Basic initialization
     * await MyCashlessSDK.getInstance().initialize({
     *   production: true,
     *   stripePublishableKey: 'pk_live_xxx',
     * });
     *
     * // With custom storage adapters
     * await MyCashlessSDK.getInstance().initialize({
     *   production: true,
     * }, {
     *   storage: mySecureStorageAdapter,
     *   database: mySQLiteAdapter,
     * });
     * ```
     */
    initialize(config: SDKConfig, adapters?: {
        storage?: StorageAdapter;
        database?: DatabaseAdapter;
    }): Promise<void>;
    /**
     * Restore a previous session automatically.
     * Called at the end of initialize() to restore event, wallet, and auth state
     * so the user doesn't have to re-login or re-connect every time.
     *
     * Mirrors:
     * - iOS: SplashScreenVC checks currentEventUid → AccountVC.initVariable() calls restoreDB()
     * - Android: SplashViewModel checks authToken + eventUid → ChipDataManager.restore()
     */
    private restoreSession;
    /**
     * Set the current event by UID
     * Fetches event info from API, saves to cache/DB, initializes wallet
     * Matches Android ConnectEventActivity flow
     */
    setEvent(eventUid: string): Promise<Event | null>;
    /**
     * Connect to an event by nickname/code
     * Matches Android: ApiClient.getEventInfoByNickname(code)
     * Use this when the user enters an event code
     */
    connectByCode(nickname: string): Promise<Event | null>;
    /**
     * Sync event connection for logged-in users
     * Fetches EventConnection from backend (includes dchip_id, balance, user info)
     * Matches Android: ApiClient.getEventConnection() → ServiceWorker.GetEventDetail()
     * Call this after login to get the user's connection to the current event
     */
    syncEventConnection(): Promise<EventConnection | null>;
    /**
     * Get the current event info
     * Returns cached event data without making an API call
     */
    getCurrentEvent(): Promise<{
        id: number;
        uid: string;
        name: string;
        currency: string;
        place: string;
        type: string;
        imageUrl: string;
        logoUrl: string;
    } | null>;
    /**
     * Internal: apply event data (cache, DB, ChipData init)
     * Shared by setEvent() and connectByCode()
     */
    private applyEvent;
    /**
     * Normalize EventConfig fields from backend JSON to SDK types.
     * Backend sends: is_pa_reload, is_pa_ticket, max_dchip_balance, max_dchip_promo
     * SDK expects: reload_allowed, access_allowed, chip_max_balance, chip_max_promo
     */
    private normalizeEventConfig;
    /**
     * Start background sync
     * Call this after setEvent() to enable automatic synchronization
     */
    startSync(): void;
    /**
     * Stop background sync
     */
    stopSync(): void;
    /**
     * Trigger immediate sync
     */
    syncNow(): Promise<SyncResult>;
    /**
     * Set a callback to be notified when background sync completes
     * after QR processing. Allows the host app to show sync status or retry.
     */
    setSyncStatusCallback(callback: SyncStatusCallback | null): void;
    /**
     * Sync balance from server via EventConnection endpoint.
     * Used as a fallback after payment when transfer-based sync returns empty.
     * The server knows the real balance; this applies it to ChipData.
     * Returns true if balance was updated.
     */
    syncBalanceFromServer(): Promise<boolean>;
    /**
     * Create a local BALANCE transaction after a successful Stripe payment.
     * Use this as a fallback when transfer-based sync returns empty.
     * The amount (in cents) is applied to ChipData and saved to DB.
     * @param balanceCents - The balance amount in cents (e.g., 5000 = $50.00)
     * @param promoCents - Optional promo amount in cents
     */
    applyReloadLocally(balanceCents: number, promoCents?: number): Promise<boolean>;
    /**
     * Well-known FastPass QR type strings (field[1] in FastPass QR codes)
     */
    private static readonly FASTPASS_TYPES;
    /**
     * Process a scanned mPOS QR code to update wallet state.
     *
     * The mPOS generates an AES-encrypted QR after completing a transaction
     * (reload, sale, refund, etc.). This method decrypts, parses, validates,
     * and applies the transaction to the local wallet.
     *
     * The integrator brings their own camera/scanner — this method only needs
     * the raw encrypted string from the scanned QR.
     *
     * @param encryptedQR - The raw AES-encrypted string from the mPOS QR code
     * @returns ProcessQRResult with status, transaction, and updated balance
     */
    processScannedQR(encryptedQR: string): Promise<ProcessQRResult>;
    /**
     * Get human-readable message for a transaction type
     */
    private getTransactionMessage;
    /**
     * Get the auth service
     */
    get authService(): AuthService;
    /**
     * Get the wallet service
     */
    get walletService(): WalletService;
    /**
     * Get the payment service
     */
    get paymentService(): PaymentService;
    /**
     * Get the sync service
     */
    get syncService(): SyncService;
    /**
     * Check if SDK is initialized
     */
    isInitialized(): boolean;
    /**
     * Check if an event is set
     */
    isEventSet(): boolean;
    /**
     * Get current configuration
     */
    getConfig(): SDKConfig | null;
    /**
     * Get current state
     */
    getState(): SDKState;
    /**
     * Clear all SDK data (logout + clear local data)
     */
    clearAllData(): Promise<void>;
    /**
     * Reset the SDK (for testing or re-initialization)
     */
    static reset(): void;
    private ensureInitialized;
    private ensureEventSet;
}
//# sourceMappingURL=MyCashlessSDK.d.ts.map