/**
 * Authentication Service
 * Handles user login, registration, and session management
 */
import type { User, AuthResult } from '../core/types';
import type { RegisterRequest, UpdateUserRequest } from '../api/types';
/**
 * AuthService class
 * Provides authentication operations
 */
export declare class AuthService {
    private apiClient;
    constructor();
    /**
     * Format phone number to match backend expectation: +DIGITS
     * Mirrors Android: replaceAll("[\\D]", "") then prepend "+" if missing
     */
    private formatPhone;
    /**
     * Login with phone and password
     */
    login(phone: string, password: string): Promise<AuthResult>;
    /**
     * Login or register using a Fanki token.
     * The backend validates the token against Fanki's API, creates the
     * user if it doesn't exist, and returns a MyCashless JWT.
     */
    loginWithFankiToken(fankiToken: string): Promise<AuthResult>;
    /**
     * Register a new user
     */
    register(userData: RegisterRequest, firebaseToken?: string): Promise<AuthResult>;
    /**
     * Reset password
     */
    resetPassword(phone: string, newPassword: string, firebaseToken?: string): Promise<boolean>;
    /**
     * Logout
     */
    logout(): Promise<void>;
    /**
     * Check if phone number exists
     */
    checkPhoneExists(phone: string): Promise<boolean>;
    /**
     * Start WhatsApp verification
     */
    startWhatsappVerification(phone: string): Promise<boolean>;
    /**
     * Check WhatsApp verification code
     */
    checkWhatsappVerification(phone: string, code: string): Promise<boolean>;
    /**
     * Update user profile
     */
    updateUser(userData: UpdateUserRequest): Promise<User | null>;
    /**
     * Delete user account
     */
    deleteAccount(): Promise<boolean>;
    /**
     * Check if user is logged in
     */
    isLoggedIn(): Promise<boolean>;
    /**
     * Get current user from cache
     */
    getCurrentUser(): Promise<Partial<User> | null>;
    /**
     * Check if session is expired
     */
    isSessionExpired(): Promise<boolean>;
    /**
     * Restore session from stored token
     */
    restoreSession(): Promise<boolean>;
}
//# sourceMappingURL=AuthService.d.ts.map