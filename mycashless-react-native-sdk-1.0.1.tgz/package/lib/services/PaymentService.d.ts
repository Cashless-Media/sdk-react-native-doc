/**
 * Payment Service
 * Handles Stripe, PayPal and payment method management
 * Mirrors Android PaymentActivity/NewCardPaymentActivity/PayPalPayActivity
 * and iOS PaymentVC/NewCardPaymentVC/PayPalPaymentVC
 */
import type { ReloadAmount, BillingInfo } from '../core/types';
import type { PayPalCaptureOrderResponse, PayableConfigResponse } from '../api/types';
/**
 * Result from createPaymentIntent
 */
export interface PaymentIntentResult {
    clientSecret: string;
    connectedAccountId?: string;
    paymentIntentStatus?: string;
    /** True if payment was already completed server-side (no need for PaymentSheet) */
    alreadySucceeded: boolean;
    /** True if payment needs server confirmation via confirmPaymentIntent */
    requiresCapture: boolean;
}
/**
 * Result from createSetupIntent (for saving a card)
 */
export interface SetupIntentResult {
    clientSecret: string;
    customerId?: string;
}
/**
 * Saved payment method (card)
 */
export interface SavedPaymentMethod {
    id: string;
    customerId: string;
    brand: string;
    last4: string;
    expMonth: number;
    expYear: number;
    country?: string;
}
/**
 * PayPal order creation result
 */
export interface PayPalOrderResult {
    orderId: string;
    transferIds: number[];
    tableIds: number[];
    serviceFee: number;
}
/**
 * MercadoPago preference creation result
 */
export interface MercadoPagoPreferenceResult {
    preferenceId: string;
    initPoint: string;
    externalReference: string;
    amount: number;
    currency: string;
    serviceFee: number;
    transferIds: number[];
    tableIds: number[];
}
/**
 * MercadoPago payment verification result
 */
export interface MercadoPagoVerifyResult {
    status: 'approved' | 'pending' | 'failed';
    statusDetail: string;
    message: string;
    paymentId: string;
    amount: number;
    currency: string;
    isActive: boolean;
    balance: number;
}
/**
 * Available payment methods for current event
 */
export interface AvailablePaymentMethods {
    stripe: boolean;
    paypal: boolean;
    cash: boolean;
    mercadoPago: boolean;
    applePay: boolean;
    googlePay: boolean;
}
/**
 * PaymentService class
 * Provides Stripe, PayPal, and payment method operations
 */
export declare class PaymentService {
    private apiClient;
    constructor();
    /**
     * Get available payment methods for current event
     */
    getAvailablePaymentMethods(): Promise<AvailablePaymentMethods>;
    /**
     * Get reload amounts configured for the event
     */
    getReloadAmounts(): Promise<ReloadAmount[]>;
    /**
     * Get payable config (PayPal client ID, Stripe readiness, etc.)
     */
    getPayableConfig(): Promise<PayableConfigResponse | null>;
    /**
     * Get the Stripe publishable key for current environment and country
     */
    getStripePublishableKey(): Promise<string>;
    /**
     * Get Stripe connected account ID (if applicable)
     */
    getConnectedAccountId(): Promise<string | null>;
    /**
     * Get Apple Pay merchant ID
     */
    getApplePayMerchantId(): string;
    /**
     * Create a PaymentIntent for balance reload
     * Mirrors Android PaymentActivity.createPaymentIntent()
     * and iOS PaymentVC.createPaymentIntent()
     *
     * @param reloadDetail - JSON string with balance amounts, e.g. '{"5000":1}'
     * @param customerId - Stripe customer ID (for saved card), null for new card
     * @param paymentMethodId - Stripe payment method ID (for saved card), null for new card
     * @param referralCode - Optional referral/promo code
     */
    createPaymentIntent(reloadDetail: string, customerId?: string | null, paymentMethodId?: string | null, referralCode?: string): Promise<PaymentIntentResult | null>;
    /**
     * Confirm a PaymentIntent that has status "requires_capture"
     * Mirrors Android/iOS confirmPaymentIntent() after PaymentSheet success
     *
     * @param paymentIntentId - The PaymentIntent ID (pi_xxx)
     */
    confirmPaymentIntent(paymentIntentId: string): Promise<boolean>;
    /**
     * Apply reload balance to chip after successful payment
     * Calls the use-balance-by-dchip endpoint to mark transfers as used
     * Then triggers sync to download and apply the balance
     */
    applyReloadToChip(): Promise<boolean>;
    /**
     * Create a SetupIntent for saving a card without charging
     * Mirrors Android AddPaymentMethodActivity and iOS AddPaymentMethodVC
     */
    createSetupIntent(): Promise<SetupIntentResult | null>;
    /**
     * Get saved payment methods (cards)
     */
    getPaymentMethods(): Promise<SavedPaymentMethod[]>;
    /**
     * Delete a saved payment method
     */
    deletePaymentMethod(paymentMethodId: string): Promise<boolean>;
    /**
     * Get saved billing info
     */
    getBillingInfo(): Promise<BillingInfo | null>;
    /**
     * Save billing info
     */
    saveBillingInfo(billingInfo: BillingInfo): Promise<boolean>;
    /**
     * Get PayPal client ID for the current event
     */
    getPayPalClientId(): Promise<string | null>;
    /**
     * Create a PayPal order for balance reload
     * Mirrors Android PayPalPayActivity.createOrder()
     * and iOS PayPalPaymentVC.createOrder()
     */
    createPayPalOrder(reloadDetail: string, referralCode?: string): Promise<PayPalOrderResult | null>;
    /**
     * Capture a PayPal order after user approval
     * Mirrors Android PayPalPayActivity.captureOrder()
     * and iOS PayPalPaymentVC.captureOrder()
     */
    capturePayPalOrder(orderId: string, transferIds: number[], tableIds: number[], serviceFee: number): Promise<PayPalCaptureOrderResponse | null>;
    /**
     * Create a MercadoPago preference for balance reload
     * Mirrors iOS MercadoPagoPaymentVC.createPreference()
     * Returns the checkout URL (initPoint) to open in a browser/WebView
     *
     * @param reloadDetail - JSON string with balance amounts
     * @param referralCode - Optional referral/promo code
     */
    createMercadoPagoPreference(reloadDetail: string, referralCode?: string): Promise<MercadoPagoPreferenceResult | null>;
    /**
     * Verify a MercadoPago payment with the backend
     * Mirrors iOS MercadoPagoPaymentVC.verifyPaymentWithBackend()
     *
     * Uses exponential backoff retry logic:
     * - Attempt 1: 2s delay
     * - Attempt 2: 4s delay
     * - Attempt 3: 8s delay
     *
     * @param externalReference - The external reference from createPreference. If omitted, reads from cache.
     * @param maxRetries - Maximum retry attempts (default: 3)
     */
    verifyMercadoPagoPayment(externalReference?: string, maxRetries?: number): Promise<MercadoPagoVerifyResult>;
    /**
     * Get error message for a MercadoPago status_detail code
     * Mirrors iOS MercadoPagoErrorHelper.getErrorMessage()
     */
    getMercadoPagoErrorMessage(statusDetail: string): string;
    /**
     * Check if a MercadoPago error suggests using a different payment method
     * Mirrors iOS MercadoPagoErrorHelper.shouldSuggestDifferentMethod()
     */
    shouldSuggestDifferentMethod(statusDetail: string): boolean;
    /**
     * Calculate total with service fees
     * Mirrors Android/iOS fee calculation logic
     */
    calculateTotalWithFees(amount: number): Promise<{
        subtotal: number;
        fee: number;
        total: number;
        feePercent: number;
    }>;
    /**
     * Build reload detail JSON from selected amounts
     * Backend expects: {"balance": {"<reload_amount_id>": <quantity>}}
     * Mirrors iOS ReloadBalanceVC.swift lines 455-495
     *
     * @param amounts - Array of ReloadAmount selections with quantity
     */
    buildReloadDetail(amounts: Array<{
        id: number;
        quantity: number;
        is_other?: boolean;
        amount?: number;
    }>): string;
    /**
     * Format amount for display (cents → currency string)
     */
    formatAmount(amountInCents: number, currency?: string): string;
}
//# sourceMappingURL=PaymentService.d.ts.map