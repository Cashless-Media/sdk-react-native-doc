/**
 * API Endpoints
 * All REST API endpoint definitions
 * Mirrors Android ApiInterface and iOS endpoints
 */
/**
 * Authentication endpoints
 */
export declare const AuthEndpoints: {
    readonly login: "/api/v2.0/auth/login";
    readonly register: "/api/v2.0/auth/register";
    readonly registerWithCode: (code: string, eventId: number) => string;
    readonly setPassword: "/api/v2.0/auth/set/password";
    readonly checkTerm: "/api/v2.0/auth/term/check";
    readonly checkPhoneExists: (phone: string) => string;
    readonly verifyWhatsappStart: "/api/v2.0/verify/whatsapp/start";
    readonly verifyWhatsappCheck: "/api/v2.0/verify/whatsapp/check";
    readonly fankiLogin: "/api/v2.0/auth/fanki/login";
};
/**
 * User endpoints
 */
export declare const UserEndpoints: {
    readonly updateUser: "/api/v2.0/users";
    readonly deleteAccount: "/api/v2.0/users/delete/me";
    readonly getUserByCode: (code: string) => string;
    readonly getBillingInfo: "/api/v2.0/me/billinginfo";
    readonly saveBillingInfo: "/api/v2.0/billinginfo/stripe";
};
/**
 * Event endpoints
 */
export declare const EventEndpoints: {
    readonly getEventInfo: (uid: string) => string;
    readonly getEventByNickname: (nickname: string) => string;
    readonly getLastTwoEvents: (nickname: string) => string;
    readonly getEventConnection: (uid: string) => string;
    readonly updateCustomFields: (uid: string) => string;
    readonly getPayableConfig: (uid: string) => string;
    readonly getReloadAmounts: (uid: string) => string;
};
/**
 * Transfer endpoints (Balance & Tickets)
 */
export declare const TransferEndpoints: {
    readonly getActiveBalanceTransfers: (eventUid: string) => string;
    readonly useReloadTransactions: "/api/v2.0/transfers/use-balance-by-dchip/all";
    readonly getActiveTicketTransfers: (eventUid: string) => string;
    readonly getAllValidTicketTransfers: (eventUid: string) => string;
    readonly depositTransfers: "/api/v2.0/transfers/deposit";
    readonly markTicketAsUsed: (eventId: number) => string;
    readonly transferToAnotherDevice: "/api/v2.0/transfers/ticket/transfer-ticket-to-another-device";
    readonly shareWithFriend: "/api/v2.0/transfers/share/friend-invite/email";
    readonly sendTicketEmail: "/api/v2.0/transfers/ticket/friend-invite/email";
    readonly validateFriendInvite: "/api/v2.0/transfers/friend-invite/validate";
    readonly acceptFriendInvite: "/api/v2.0/transfers/friend-invite/accept";
    readonly validateTicketInvite: "/api/v2.0/transfers/ticket/friend-invite/validate";
    readonly acceptTicketInvite: "/api/v2.0/transfers/ticket/friend-invite/accept";
    readonly getTransferByUid: (uid: string) => string;
    readonly getSentTransfers: (eventUid: string) => string;
    readonly reclaimTransfer: (eventId: number, transferUid: string) => string;
    readonly createFreeTicketTransfers: "/api/v2.0/transfers/create-free-ticket-transfers";
    readonly purchaseTicketsWithBalance: "/api/v2.0/transfers/dchip/payment-ticket-transfers";
    readonly shareWithWristband: "/api/v2.0/transactions/wristband/share";
};
/**
 * Access (Ticket Types) endpoints
 */
export declare const AccessEndpoints: {
    readonly getAllAccessTypes: (eventUid: string) => string;
    readonly getEventAccessTypes: (eventUid: string) => string;
    readonly validateAccessQuantity: (accessTypeUid: string, eventUid: string, quantity: number, totalQuantity: number) => string;
    readonly getAddonAccesses: (eventUid: string) => string;
};
/**
 * Token endpoints
 */
export declare const TokenEndpoints: {
    readonly getTokens: (eventUid: string) => string;
    readonly getTokenByCode: (eventUid: string, tokenCode: string) => string;
    readonly validateTokenQuantity: (tokenNumber: number, eventUid: string, quantity: number, totalQuantity: number) => string;
};
/**
 * Transaction endpoints
 */
export declare const TransactionEndpoints: {
    readonly syncDChipTransaction: "/api/v2.0/dchip/transaction/sync";
    readonly uploadDChipInfo: "/api/v2.0/dchip/logs";
    readonly syncVirtualPOSTransaction: "/api/v2.0/transactions/sync";
    readonly canBeRefundedByStripe: (eventId: number, dchipId: string) => string;
};
/**
 * Check-In endpoints
 */
export declare const CheckInEndpoints: {
    readonly checkIn: "/api/v2.0/fpcheckin";
    readonly uploadCheckIn: (eventId: number) => string;
};
/**
 * Stripe Payment endpoints
 */
export declare const StripeEndpoints: {
    readonly createPaymentIntent: "/api/v2.0/stripe/create-payment-intent";
    readonly createSetupIntent: "/api/v2.0/stripe/create-setup-intent";
    readonly confirmPaymentIntent: "/api/v3.0/stripe/confirm-payment-intent";
    readonly getPaymentMethods: (eventId: number) => string;
    readonly detachPaymentMethod: (eventId: number) => string;
};
/**
 * PayPal Payment endpoints
 */
export declare const PayPalEndpoints: {
    readonly createOrder: "/api/v3.0/paypal/create-order";
    readonly captureOrder: "/api/v3.0/paypal/capture-order";
};
/**
 * MercadoPago Payment endpoints
 */
export declare const MercadoPagoEndpoints: {
    readonly createPreference: "/api/v3.0/mercadopago/mobile/create-preference";
    readonly verify: (externalReference: string) => string;
};
/**
 * Braintree Payment endpoints
 */
export declare const BraintreeEndpoints: {
    readonly getClientToken: (eventId: number) => string;
    readonly createPurchase: "/api/v3.0/braintree/createpurchase";
};
/**
 * Refund endpoints
 */
export declare const RefundEndpoints: {
    readonly getRefundDetails: (eventId: number, nfcId: string) => string;
    readonly dchipAutoRefundStripe: "/api/v2.0/refunds/dchip-auto-refund-stripe";
    readonly refund: "/api/refunds";
    readonly getLandingRefund: "/api/new/landing/nfc";
};
/**
 * Notification endpoints
 */
export declare const NotificationEndpoints: {
    readonly getNotifications: "/api/v2.0/notifications";
};
/**
 * Promotion endpoints
 */
export declare const PromotionEndpoints: {
    readonly redeemPromotion: "/api/v2.0/transfers/redeem_promotion";
};
/**
 * Other endpoints
 */
export declare const OtherEndpoints: {
    readonly getLatestVersion: "/api/v2.0/dchip/current";
    readonly getBanks: "/api/banks/clabe";
    readonly donate: "/api/donates";
    readonly createInvoice: "/api/invoices";
    readonly getVirtualDeviceProducts: (eventUid: string, deviceUid: string) => string;
    readonly createDChipNfc: "/api/v3.0/dchipnfc/create";
    readonly getDChipNfcList: (eventUid: string, dchipId: string) => string;
    readonly updateDChipNfc: "/api/v2.0/dchipnfc/update";
    readonly editDChipNfc: "/api/v3.0/dchipnfc/edit";
};
/**
 * All endpoints combined for reference
 */
export declare const Endpoints: {
    readonly Auth: {
        readonly login: "/api/v2.0/auth/login";
        readonly register: "/api/v2.0/auth/register";
        readonly registerWithCode: (code: string, eventId: number) => string;
        readonly setPassword: "/api/v2.0/auth/set/password";
        readonly checkTerm: "/api/v2.0/auth/term/check";
        readonly checkPhoneExists: (phone: string) => string;
        readonly verifyWhatsappStart: "/api/v2.0/verify/whatsapp/start";
        readonly verifyWhatsappCheck: "/api/v2.0/verify/whatsapp/check";
        readonly fankiLogin: "/api/v2.0/auth/fanki/login";
    };
    readonly User: {
        readonly updateUser: "/api/v2.0/users";
        readonly deleteAccount: "/api/v2.0/users/delete/me";
        readonly getUserByCode: (code: string) => string;
        readonly getBillingInfo: "/api/v2.0/me/billinginfo";
        readonly saveBillingInfo: "/api/v2.0/billinginfo/stripe";
    };
    readonly Event: {
        readonly getEventInfo: (uid: string) => string;
        readonly getEventByNickname: (nickname: string) => string;
        readonly getLastTwoEvents: (nickname: string) => string;
        readonly getEventConnection: (uid: string) => string;
        readonly updateCustomFields: (uid: string) => string;
        readonly getPayableConfig: (uid: string) => string;
        readonly getReloadAmounts: (uid: string) => string;
    };
    readonly Transfer: {
        readonly getActiveBalanceTransfers: (eventUid: string) => string;
        readonly useReloadTransactions: "/api/v2.0/transfers/use-balance-by-dchip/all";
        readonly getActiveTicketTransfers: (eventUid: string) => string;
        readonly getAllValidTicketTransfers: (eventUid: string) => string;
        readonly depositTransfers: "/api/v2.0/transfers/deposit";
        readonly markTicketAsUsed: (eventId: number) => string;
        readonly transferToAnotherDevice: "/api/v2.0/transfers/ticket/transfer-ticket-to-another-device";
        readonly shareWithFriend: "/api/v2.0/transfers/share/friend-invite/email";
        readonly sendTicketEmail: "/api/v2.0/transfers/ticket/friend-invite/email";
        readonly validateFriendInvite: "/api/v2.0/transfers/friend-invite/validate";
        readonly acceptFriendInvite: "/api/v2.0/transfers/friend-invite/accept";
        readonly validateTicketInvite: "/api/v2.0/transfers/ticket/friend-invite/validate";
        readonly acceptTicketInvite: "/api/v2.0/transfers/ticket/friend-invite/accept";
        readonly getTransferByUid: (uid: string) => string;
        readonly getSentTransfers: (eventUid: string) => string;
        readonly reclaimTransfer: (eventId: number, transferUid: string) => string;
        readonly createFreeTicketTransfers: "/api/v2.0/transfers/create-free-ticket-transfers";
        readonly purchaseTicketsWithBalance: "/api/v2.0/transfers/dchip/payment-ticket-transfers";
        readonly shareWithWristband: "/api/v2.0/transactions/wristband/share";
    };
    readonly Access: {
        readonly getAllAccessTypes: (eventUid: string) => string;
        readonly getEventAccessTypes: (eventUid: string) => string;
        readonly validateAccessQuantity: (accessTypeUid: string, eventUid: string, quantity: number, totalQuantity: number) => string;
        readonly getAddonAccesses: (eventUid: string) => string;
    };
    readonly Token: {
        readonly getTokens: (eventUid: string) => string;
        readonly getTokenByCode: (eventUid: string, tokenCode: string) => string;
        readonly validateTokenQuantity: (tokenNumber: number, eventUid: string, quantity: number, totalQuantity: number) => string;
    };
    readonly Transaction: {
        readonly syncDChipTransaction: "/api/v2.0/dchip/transaction/sync";
        readonly uploadDChipInfo: "/api/v2.0/dchip/logs";
        readonly syncVirtualPOSTransaction: "/api/v2.0/transactions/sync";
        readonly canBeRefundedByStripe: (eventId: number, dchipId: string) => string;
    };
    readonly CheckIn: {
        readonly checkIn: "/api/v2.0/fpcheckin";
        readonly uploadCheckIn: (eventId: number) => string;
    };
    readonly Stripe: {
        readonly createPaymentIntent: "/api/v2.0/stripe/create-payment-intent";
        readonly createSetupIntent: "/api/v2.0/stripe/create-setup-intent";
        readonly confirmPaymentIntent: "/api/v3.0/stripe/confirm-payment-intent";
        readonly getPaymentMethods: (eventId: number) => string;
        readonly detachPaymentMethod: (eventId: number) => string;
    };
    readonly PayPal: {
        readonly createOrder: "/api/v3.0/paypal/create-order";
        readonly captureOrder: "/api/v3.0/paypal/capture-order";
    };
    readonly MercadoPago: {
        readonly createPreference: "/api/v3.0/mercadopago/mobile/create-preference";
        readonly verify: (externalReference: string) => string;
    };
    readonly Braintree: {
        readonly getClientToken: (eventId: number) => string;
        readonly createPurchase: "/api/v3.0/braintree/createpurchase";
    };
    readonly Refund: {
        readonly getRefundDetails: (eventId: number, nfcId: string) => string;
        readonly dchipAutoRefundStripe: "/api/v2.0/refunds/dchip-auto-refund-stripe";
        readonly refund: "/api/refunds";
        readonly getLandingRefund: "/api/new/landing/nfc";
    };
    readonly Notification: {
        readonly getNotifications: "/api/v2.0/notifications";
    };
    readonly Promotion: {
        readonly redeemPromotion: "/api/v2.0/transfers/redeem_promotion";
    };
    readonly Other: {
        readonly getLatestVersion: "/api/v2.0/dchip/current";
        readonly getBanks: "/api/banks/clabe";
        readonly donate: "/api/donates";
        readonly createInvoice: "/api/invoices";
        readonly getVirtualDeviceProducts: (eventUid: string, deviceUid: string) => string;
        readonly createDChipNfc: "/api/v3.0/dchipnfc/create";
        readonly getDChipNfcList: (eventUid: string, dchipId: string) => string;
        readonly updateDChipNfc: "/api/v2.0/dchipnfc/update";
        readonly editDChipNfc: "/api/v3.0/dchipnfc/edit";
    };
};
//# sourceMappingURL=endpoints.d.ts.map