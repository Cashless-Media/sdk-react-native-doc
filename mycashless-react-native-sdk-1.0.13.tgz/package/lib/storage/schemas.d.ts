/**
 * SQLite Database Schemas
 * Defines table structures for local data persistence
 * Mirrors Android DBManager and iOS SQLiteHelper
 */
/**
 * SQL statements for creating tables
 */
export declare const CREATE_TABLE_STATEMENTS: {
    /**
     * Transaction table - stores all payment transactions
     */
    "\"Transaction\"": string;
    /**
     * PATransfer table - stores balance and ticket transfers
     */
    PATransfer: string;
    /**
     * Event table - caches event information
     */
    Event: string;
    /**
     * CheckIn table - stores attendance records
     */
    CheckIn: string;
    /**
     * Notification table - stores push notifications
     * Matches Android Notification model and iOS MNotification
     */
    Notification: string;
    /**
     * ParentData table - stores parent/child tracking
     * Matches Android/iOS ParentData model
     */
    ParentData: string;
};
/**
 * SQL statements for creating indexes
 */
export declare const CREATE_INDEX_STATEMENTS: string[];
/**
 * Get all tables creation SQL
 */
export declare function getAllCreateTableSQL(): string[];
/**
 * Get all indexes creation SQL
 */
export declare function getAllCreateIndexSQL(): string[];
/**
 * Database version for migrations
 */
export declare const DATABASE_VERSION: 17;
/**
 * Database name
 */
export declare const DATABASE_NAME: "mycashless.db";
/**
 * Migration scripts by version
 * Add new migrations here when schema changes
 */
export declare const MIGRATIONS: Record<number, string[]>;
/**
 * Get migrations to run from current version to target version
 */
export declare function getMigrationsToRun(currentVersion: number, targetVersion?: number): string[];
/**
 * Columns that can be SAFELY added with `ALTER TABLE ... ADD COLUMN` to repair a
 * database created by an older SDK whose schema predates these columns.
 *
 * This is the robust safety net behind the versioned MIGRATIONS: it diffs the
 * live `PRAGMA table_info` against this list and adds whatever is missing,
 * regardless of `user_version`. Only nullable / DEFAULT-ed columns are listed —
 * SQLite cannot `ADD COLUMN` a NOT NULL column without a default, and the
 * NOT NULL columns (`id`, `uid`, `event_id`, `type`, `created_time`) have always
 * existed since the very first schema, so they are never missing.
 */
export declare const REPAIRABLE_COLUMNS: Record<string, {
    name: string;
    def: string;
}[]>;
/**
 * Column definitions for type safety
 */
export declare const TransactionColumns: {
    readonly ID: "id";
    readonly UID: "uid";
    readonly TRANS_NUMBER: "trans_number";
    readonly EVENT_ID: "event_id";
    readonly TYPE: "type";
    readonly PAYMENT_TYPE: "payment_type";
    readonly BALANCE: "balance";
    readonly TIP_BALANCE: "tip_balance";
    readonly TRANSFERRED_BALANCE: "transferred_balance";
    readonly CURRENCY: "currency";
    readonly TAX: "tax";
    readonly PROMO: "promo";
    readonly TOKEN_DETAIL: "token_detail";
    readonly NFC_ID: "nfc_id";
    readonly DEV_MAC: "dev_mac";
    readonly OPERATOR_NAME: "operator_name";
    readonly STATUS: "status";
    readonly CREATED_TIME: "created_time";
    readonly IS_SYNCED: "is_synced";
    readonly USER_ID: "user_id";
    readonly LAT: "lat";
    readonly LNG: "lng";
    readonly NOTE: "note";
};
export declare const PATransferColumns: {
    readonly ID: "id";
    readonly UID: "uid";
    readonly TYPE: "type";
    readonly EVENT_ID: "event_id";
    readonly USER_ID: "user_id";
    readonly BUYER_ID: "buyer_id";
    readonly BALANCE: "balance";
    readonly PROMO_BALANCE: "promo_balance";
    readonly ONLINE_DETAILS: "online_details";
    readonly STATUS: "status";
    readonly TRANSACTION_IDS: "transaction_ids";
    readonly REFERRAL_CODE: "referral_code";
    readonly ACCESS_CODE: "access_code";
    readonly TICKET_NAME: "ticket_name";
    readonly TICKET_COLOR: "ticket_color";
    readonly TICKET_DETAILS: "ticket_details";
    readonly CREATE_TIME: "create_time";
    readonly UPDATE_TIME: "update_time";
    readonly CONFIRM_TIME: "confirm_time";
    readonly DEPOSIT_TIME: "deposit_time";
    readonly DEV_MAC: "dev_mac";
    readonly DEV_NAME: "dev_name";
    readonly CHECK_IN_UID: "check_in_uid";
    readonly IS_SYNCED: "is_synced";
};
export declare const CheckInColumns: {
    readonly ID: "id";
    readonly UID: "uid";
    readonly EVENT_ID: "event_id";
    readonly TYPE: "type";
    readonly DCHIP_ID: "dchip_id";
    readonly COLOR: "color";
    readonly DEV_MAC: "dev_mac";
    readonly CREATED_TIME: "created_time";
    readonly IS_SYNCED: "is_synced";
};
export declare const EventColumns: {
    readonly ID: "id";
    readonly UID: "uid";
    readonly NAME: "name";
    readonly PLACE: "place";
    readonly CURRENCY: "currency";
    readonly CURRENCY_CODE: "currency_code";
    readonly TYPE: "type";
    readonly IMAGE_URL: "image_url";
    readonly LOGO_URL: "logo_url";
    readonly BANNER_URL: "banner_url";
    readonly START_DATE: "start_date";
    readonly END_DATE: "end_date";
    readonly WELCOME_MESSAGE_EN: "welcome_message_en";
    readonly WELCOME_MESSAGE_ES: "welcome_message_es";
    readonly CONFIG: "config";
};
export declare const NotificationColumns: {
    readonly ID: "id";
    readonly EVENT_ID: "event_id";
    readonly PICTURE: "picture";
    readonly TITLE: "title";
    readonly SUMMARY_TEXT: "summary_text";
    readonly TEXT: "text";
    readonly IS_READ: "is_read";
    readonly IS_REDEEMED: "is_redeemed";
    readonly TOKEN_NUMBER: "token_number";
    readonly TOKEN_AMOUNT: "token_amount";
    readonly PROMO_AMOUNT: "promo_amount";
    readonly CREATED_AT: "created_at";
    readonly EVENT_UID: "event_uid";
    readonly LOGO_URL: "logo_url";
};
export declare const ParentDataColumns: {
    readonly ID: "id";
    readonly EVENT_ID: "event_id";
    readonly USER_ID: "user_id";
    readonly DCHIP_ID: "dchip_id";
    readonly NAME: "name";
    readonly PHONE: "phone";
    readonly AREA_NAME: "area_name";
    readonly OPERATOR_NAME: "operator_name";
    readonly OPERATOR_DEVICE: "operator_device";
    readonly CREATED_TIME: "created_time";
    readonly IS_SYNCED: "is_synced";
};
//# sourceMappingURL=schemas.d.ts.map