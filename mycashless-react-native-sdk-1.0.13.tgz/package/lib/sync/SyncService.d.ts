/**
 * Sync Service
 * Background synchronization of transactions, transfers, and check-ins
 * Mirrors Android ServiceWorker and iOS SyncService
 */
import type { SyncResult, Transaction } from '../core/types';
/**
 * SyncService class
 * Handles periodic background synchronization
 */
export declare class SyncService {
    private static instance;
    private apiClient;
    private dbManager;
    private chipData;
    private syncInterval;
    private isSyncing;
    private isSyncingTransactions;
    private isSyncingReload;
    private isSyncingAccess;
    private isSyncingCheckIns;
    private onSyncComplete?;
    private onSyncError?;
    private constructor();
    /**
     * Get singleton instance
     */
    static getInstance(): SyncService;
    /**
     * Set sync callbacks
     */
    setCallbacks(onComplete?: (result: SyncResult) => void, onError?: (error: string) => void): void;
    /**
     * Start periodic sync (every 5 minutes)
     */
    startPeriodicSync(): void;
    /**
     * Stop periodic sync
     */
    stopPeriodicSync(): void;
    /**
     * Check if sync is running
     */
    isSyncRunning(): boolean;
    /**
     * Trigger immediate sync
     */
    syncNow(): Promise<SyncResult>;
    /**
     * Sync transactions to server
     */
    private syncTransactions;
    /**
     * Build a single transaction's upload payload EXACTLY like the native apps'
     * ServiceWorker.SyncTransactions (Android) / SyncService (iOS): same field
     * names and the same conditional inclusion rules.
     *
     * - dchip_id: prefer the tx's nfc_id (set by processScannedQR / applyReloadLocally),
     *   otherwise derive the 16-char event-prefixed id like the native apps.
     * - String defaults are mandatory for the backend's strict validation
     *   (every field is non-nullable); locally-created transactions leave some empty.
     * - user_id only when > 0; lat/lng only when both non-zero (native omits otherwise).
     */
    private buildSyncItem;
    /**
     * POST a batch of transaction items to the backend and report whether the
     * backend accepted them.
     *
     * Parity with native: uploads WITHOUT an Authorization Bearer header (the
     * cardholder apps use getApiNoneAuthService / noneAuthCodeService). The backend
     * identifies the wallet from the body (user_id / dchip_id), not the token.
     */
    private postTransactions;
    /**
     * Upload a single transaction and report whether the backend accepted it.
     *
     * Used by processScannedQR to drive the native "green vs yellow" screen:
     * a successful upload means the operator's mPOS will auto-close the sale over
     * the backend socket (green); a failure means offline/retry-later (yellow,
     * operator must scan the QR). On success the transaction is marked synced so
     * the periodic sync won't re-send it.
     */
    uploadTransaction(tx: Transaction): Promise<boolean>;
    /**
     * Download active balance transfers from the backend and apply them to
     * the local wallet. Equivalent to iOS SyncService.syncReloadTransfer and
     * Android TransferRepository.useReloadTransactions.
     *
     * Returns the canonical Transaction list created by the backend so callers
     * (e.g. WalletService.syncOnlineReloads) can show them in the UI immediately.
     */
    syncReloadTransfers(eventUid?: string): Promise<{
        synced: number;
        transactions: Transaction[];
        error?: string;
    }>;
    /**
     * Sync access (ticket) transfers with conflict resolution
     */
    private syncAccessTransfers;
    /**
     * Sync used transfer status to server
     */
    private syncUsedTransfers;
    /**
     * Upload DChip device info
     */
    private uploadDChipInfo;
    /**
     * Sync check-ins to server
     */
    private syncCheckIns;
    /**
     * Get last sync time
     */
    getLastSyncTime(): Promise<string | null>;
    /**
     * Reset singleton (for testing)
     */
    static resetInstance(): void;
}
//# sourceMappingURL=SyncService.d.ts.map