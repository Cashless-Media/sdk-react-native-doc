/**
 * QR Generator
 * Builds the encrypted "transaction confirmation" QR that the cardholder app
 * displays AFTER processing an mPOS QR, so the mPOS can scan it back and close
 * the purchase/sale.
 *
 * This mirrors the native apps exactly:
 *   - Android: QRUtil.getTransactionQR() (shown in TransactionUploadSuccess/FailActivity)
 *   - iOS:     QRUtil.getTransactionQRCode() (shown in TransactionUploadSuccess/FailVC)
 *
 * The mPOS scans this QR in DChipPayActivity / DirectPaymentActivity and parses
 * it with QRUtil.parseTransactionQRCode() to mark the pre-created (incomplete)
 * transaction as complete and clear the cart.
 *
 * QR format — 16 pipe-delimited fields, AES-CBC encrypted with the event option key:
 *   0: event_id        8: token_detail (JSON)
 *   1: uid             9: nfc_id (cardholder dChip id)
 *   2: trans_number   10: dev_mac
 *   3: type           11: operator_name
 *   4: payment_type   12: usercode
 *   5: status         13: age flag (1 = under 18, else 0)
 *   6: balance        14: NData (encrypted 24-byte wallet, key = getUID(nfc_id))
 *   7: promo          15: timestamp (ISO8601)
 */
import type { Transaction } from '../core/types';
/**
 * Build the encrypted transaction confirmation QR string for a processed
 * transaction. The returned string is ready to be rendered as a QR image by the
 * host app (e.g. with react-native-qrcode-svg) for the mPOS to scan.
 *
 * @param transaction - The transaction that was just applied in processScannedQR
 * @returns Base64 AES ciphertext, or '' if required data is missing
 */
export declare function buildTransactionConfirmationQR(transaction: Transaction): Promise<string>;
//# sourceMappingURL=QRGenerator.d.ts.map