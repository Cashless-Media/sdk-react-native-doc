/**
 * Wallet Service
 * Manages balance, promo, tokens, and transaction history
 */
import { TransactionType, PaymentType } from '../core/constants';
import type { WalletBalance, Transaction, TokenAmount, ReloadAmount } from '../core/types';
import type { WalletIdentityResponse } from '../api/types';
/**
 * WalletService class
 * Provides wallet management operations
 */
export declare class WalletService {
    private chipData;
    private dbManager;
    private apiClient;
    constructor();
    /**
     * Get current wallet balance
     */
    getBalance(): WalletBalance;
    /**
     * Get balance in currency format (dollars instead of cents)
     */
    getBalanceFormatted(): {
        balance: number;
        promo: number;
        total: number;
        tokens: TokenAmount;
    };
    /**
     * Get available reload amounts for purchase
     */
    getReloadAmounts(eventUid: string): Promise<ReloadAmount[]>;
    /**
     * Get transaction history
     */
    getTransactionHistory(): Promise<Transaction[]>;
    /**
     * Get recent transactions (limited)
     */
    getRecentTransactions(limit?: number): Promise<Transaction[]>;
    /**
     * Download active online reload transfers from the backend, apply them
     * to the local wallet, and return the canonical transactions created by
     * the server. Use this when the user opens the wallet screen to make
     * sure any online reload made on another device is reflected immediately
     * (instead of waiting for the periodic sync).
     *
     * Mirrors iOS SyncService.syncReloadTransfer and Android
     * TransferRepository.useReloadTransactions.
     */
    syncOnlineReloads(): Promise<{
        synced: number;
        transactions: Transaction[];
        error?: string;
    }>;
    /**
     * Fetch the stable, user-based dchip_id from the backend.
     *
     * Route: GET /api/v2.0/wallet/id/<event_uid>  (auth required)
     *
     * The backend derives the dchip_id from user_id + event_id, so the same
     * user+event always resolves to the same wallet identity — regardless of
     * reinstall, device change, or platform (iOS ↔ Android). If the user had
     * prior dchip_transactions on this event, their historical dchip_id is
     * returned instead so existing wallets are preserved.
     *
     * The returned `dchip_id` is persisted to CachedData under
     * `StorageKeys.DEVICE_DCHIP_ID` so the rest of the SDK and host app can
     * read it without refetching.
     *
     * Requires the user to be authenticated. Returns null when no event is
     * set, the request fails, or the endpoint is not deployed — callers
     * should fall back to the locally-derived id in that case.
     */
    fetchStableDchipId(eventUid?: string): Promise<WalletIdentityResponse | null>;
    /**
     * Restore wallet state from the backend after a reinstallation.
     *
     * Requires a proxy endpoint in personalaccount-api that forwards the
     * request to cashless-backend's `/api/dChip-history` internally (the SDK
     * cannot call cashless-backend directly because the auth tokens are
     * different).
     *
     * The proxy endpoint should be:
     *   GET /api/v2.0/wallet/restore/<event_uid>
     *   Auth: required (user JWT from personalaccount-api)
     *   Response: same shape as cashless-backend's /api/dChip-history
     *
     * Until the proxy endpoint is deployed, this method falls back to
     * `syncOnlineReloads()` which only recovers ACTIVE (pending) transfers
     * — not the full transaction history.
     *
     * This only works when the dchip_id survived reinstallation (via Keychain /
     * EncryptedSharedPreferences). If the dchip_id changed, the backend won't
     * find any transactions for the new ID.
     *
     * @param proxyEndpoint Optional custom endpoint URL. When omitted, uses
     *   the default `/api/v2.0/wallet/restore/<event_uid>`.
     */
    restoreWalletFromBackend(proxyEndpoint?: string): Promise<{
        restored: boolean;
        transactionsCount: number;
        balance: number;
        promo: number;
        /** True when the backend returned a negative balance, i.e. the restore was
         *  INCOMPLETE (sales/charges without all of the user's reloads — usually the
         *  user's transactions are split across several dchip_ids). */
        incomplete?: boolean;
        /** The raw (un-clamped) balance the backend computed, for diagnostics. */
        rawBalance?: number;
        error?: string;
    }>;
    /**
     * Create a local transaction
     * Used when recording balance changes
     */
    createTransaction(params: {
        type: TransactionType;
        balance: number;
        promo?: number;
        tokenDetail?: string;
        paymentType?: PaymentType;
        note?: string;
    }): Promise<Transaction>;
    /**
     * Record a reload transaction
     */
    recordReload(amount: number, promo?: number, tokens?: TokenAmount): Promise<Transaction>;
    /**
     * Redeem a promotion code
     */
    redeemPromotion(code: string): Promise<{
        success: boolean;
        message?: string;
        transaction?: Transaction;
    }>;
    /**
     * Check if wallet has sufficient balance
     */
    hasSufficientBalance(amount: number, usePromo?: boolean): boolean;
    /**
     * Calculate payment breakdown (balance vs promo)
     */
    calculatePaymentBreakdown(amount: number): {
        balance: number;
        promo: number;
    };
    /**
     * Refresh wallet from database
     * Called after sync or manual refresh
     */
    refreshFromDB(): Promise<void>;
    /**
     * Load wallet from storage
     */
    loadWallet(): Promise<boolean>;
    /**
     * Save wallet to storage
     */
    saveWallet(): Promise<boolean>;
    /**
     * Clear wallet data
     */
    clearWallet(): Promise<void>;
    /**
     * Get total token count
     */
    getTotalTokenCount(): number;
    /**
     * Get individual token counts
     */
    getTokens(): TokenAmount;
    /**
     * Check if first reload has been done
     */
    isFirstReloaded(): boolean;
}
//# sourceMappingURL=WalletService.d.ts.map