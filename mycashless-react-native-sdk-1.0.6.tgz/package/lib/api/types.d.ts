/**
 * API Request and Response Types
 * Type definitions for API communication
 */
import type { User, Event, Transaction, PATransfer, AccessType, Token, BillingInfo, EventConfig } from '../core/types';
export interface ApiResponse<T = unknown> {
    success: boolean;
    data?: T;
    error?: string;
    statusCode: number;
}
export interface ApiError {
    message: string;
    code?: string;
    details?: Record<string, unknown>;
}
export interface LoginRequest {
    phone: string;
    password: string;
}
export interface LoginResponse {
    token: string;
    user: User;
}
export interface FankiLoginRequest {
    fanki_token: string;
}
export interface FankiLoginResponse {
    token: string;
}
export interface FankiEvent {
    id: number;
    uid: string;
    name: string;
    nick_name: string;
    date_start: string;
    date_end: string;
}
export interface FankiEventsResponse {
    events: FankiEvent[];
}
export interface RegisterRequest {
    phone: string;
    password: string;
    first_name?: string;
    last_name?: string;
    email?: string;
    gender?: string;
    birthday?: string;
}
export interface SetPasswordRequest {
    phone: string;
    password: string;
}
export interface WhatsappVerifyStartRequest {
    phone: string;
}
export interface WhatsappVerifyCheckRequest {
    phone: string;
    code: string;
}
export interface UpdateUserRequest {
    first_name?: string;
    last_name?: string;
    email?: string;
    phone?: string;
    gender?: string;
    birthday?: string;
    zipcode?: string;
    city?: string;
    country?: string;
    photo_url?: string;
}
export interface EventResponse {
    event: Event;
    config?: EventConfig;
}
export interface EventConnectionResponse {
    event?: Event;
    user?: User;
    is_complete_info?: number;
    id?: number;
    event_id?: number;
    user_id?: number;
    dchip_id?: string;
    balance?: number;
    promo_balance?: number;
    token_detail?: string;
    custom_fields?: string;
    status?: string;
}
/**
 * Response from GET /api/v2.0/wallet/id/<event_uid>.
 * Stable, user-based dchip_id that survives reinstalls and device changes.
 * Same user + same event always resolves to the same dchip_id, regardless
 * of platform or whether the device has Keychain/Auto Backup configured.
 */
export interface WalletIdentityResponse {
    dchip_id: string;
    full_dchip_id: string;
    event_id: number;
    user_id: number;
    is_new: boolean;
}
export interface UseReloadRequest {
    uids: string;
    nfc_id: string;
}
export interface DepositTransfersRequest {
    uids: string;
    nfc_id: string;
}
export interface PreloadResponse {
    transfer: PATransfer;
}
export interface AccessResponse {
    transfer: PATransfer;
    details?: {
        name: string;
        color: number;
        accessDetails?: AccessType;
    };
}
export interface ShareRequest {
    receiver_email: string;
    amount: number;
    event_id: number;
}
export interface ShareResponse {
    transaction?: Transaction;
    link?: string;
}
export interface SendTicketEmailRequest {
    transfer_uid: string;
    receiver_email: string;
}
export interface ValidateInviteRequest {
    transfer_uid: string;
    email?: string;
}
export interface AcceptInviteRequest {
    transfer_uid: string;
    event_id: number;
}
export interface MarkTicketUsedRequest {
    transfer_uid: string;
    used_time: string;
    dev_mac: string;
}
export interface TransferToDeviceRequest {
    transfer_uid: string;
    target_nfc_id: string;
}
export interface ReclaimTransferResponse {
    success: boolean;
    transfer?: PATransfer;
}
export interface SyncTransactionRequest {
    transactions: TransactionSyncItem[];
}
export interface TransactionSyncItem {
    uid: string;
    event_id: number;
    dchip_id: string;
    transaction_number?: string;
    type: number;
    balance: number;
    promo: number;
    token_detail?: string;
    operator_name?: string;
    operator_dev_mac?: string;
    status: number;
    created_time: string;
    user_id?: number;
    lat?: number;
    lng?: number;
}
export interface UploadDChipInfoRequest {
    event_id: number;
    user_id?: number;
    dchip_id: string;
    dchip_version: string;
    dchip_os: string;
    dchip_info: string;
    device_udid: string;
    fcm_token?: string;
    language: string;
    balance: number;
    promo: number;
    token_detail: string;
    active_ticket: number;
    used_ticket: number;
}
export interface CreatePaymentIntentRequest {
    receipt_email: string;
    reload_detail: string;
    event_id: number;
    payment_method_type: string;
    is_dchip: boolean;
    customer_id: string | null;
    payment_method: string | null;
    referral_code: string;
    is_open_voucher: boolean;
}
export interface PaymentIntentResponse {
    clientSecret: string;
    connectedAccountId?: string;
    connectCustomerId?: string;
    connectPaymentMethod?: string;
    paymentIntentStatus?: string;
}
export interface CreateSetupIntentRequest {
    event_id: number;
}
export interface SetupIntentResponse {
    clientSecret: string;
    customer_id?: string;
}
export interface ConfirmPaymentIntentRequest {
    event_id: number;
    pi_id: string;
}
export interface DetachPaymentMethodRequest {
    payment_method_id: string;
}
export interface PaymentMethodsResponse {
    customerId?: string;
    paymentMethods: Array<{
        id: string;
        customer: string;
        billing_details?: Record<string, unknown>;
        card?: {
            brand: string;
            last4: string;
            exp_month: number;
            exp_year: number;
            country?: string;
        };
    }>;
}
export interface PayPalCreateOrderRequest {
    event_id: number;
    reload_detail: string;
    referral_code: string;
    receipt_email: string;
    ticket_access_code: string | null;
    table_access_code: string | null;
}
export interface PayPalCreateOrderResponse {
    order_id: string;
    status: string;
    amount: string;
    currency: string;
    transfer_ids: number[];
    table_ids: number[];
    service_fee: number;
}
export interface PayPalCaptureOrderRequest {
    order_id: string;
    event_id: number;
    transfer_ids: number[];
    table_ids: number[];
    service_fee: number;
    ticket_access_code: string | null;
    table_access_code: string | null;
    token_access_code: string | null;
    is_dchip: boolean;
}
export interface PayPalCaptureOrderResponse {
    status: string;
    order_id?: string;
    capture_id?: string;
    amount?: string;
    currency?: string;
    payer?: {
        payer_id: string;
        email: string;
        name: string;
    };
}
export interface MercadoPagoCreatePreferenceRequest {
    event_id: number;
    reload_detail: string;
    receipt_email: string;
    is_dchip: boolean;
    referral_code?: string;
    nfc_id?: string;
}
export interface MercadoPagoPreferenceResponse {
    preference_id: string;
    init_point: string;
    external_reference: string;
    amount: number;
    currency: string;
    service_fee: number;
    transfer_ids: number[];
    table_ids: number[];
}
export interface MercadoPagoVerifyResponse {
    status: string;
    status_detail: string;
    message: string;
    payment_id: string | number;
    amount: number;
    currency: string;
    transfer_status: string;
    is_active: boolean;
    balance: number;
}
export interface PayableConfigResponse {
    paypal_client_id?: string;
    ready_stripe?: string;
    ready_mercado_pago?: string;
}
export interface BraintreeClientTokenResponse {
    client_token: string;
}
export interface BraintreePurchaseRequest {
    event_id: number;
    amount: number;
    nonce: string;
    device_data?: string;
}
export interface AdyenClientKeyResponse {
    clientKey: string;
    environment: 'test' | 'live';
}
export interface CreateAdyenSessionRequest {
    event_id: number;
    reload_detail: string;
    receipt_email: string;
    return_url: string;
    referral_code?: string | null;
    nfc_id?: string | null;
    is_dchip?: boolean;
    ticket_access_code?: string | null;
    table_access_code?: string | null;
    token_access_code?: string | null;
}
export interface CreateAdyenSessionResponse {
    sessionId: string;
    sessionData: string;
    merchantReference: string;
    clientKey: string;
    environment: 'test' | 'live';
    metadata?: Record<string, unknown>;
}
export interface CancelAdyenSessionRequest {
    event_id: number;
    merchant_reference: string;
}
export interface AdyenStoredPaymentMethodsResponse {
    storedPaymentMethods: unknown[];
}
export interface RefundDetailsResponse {
    eligible: boolean;
    balance: number;
    promo: number;
    refund_amount: number;
    fee_amount: number;
    net_amount: number;
}
export interface AutoRefundStripeRequest {
    event_id: number;
    nfc_id: string;
    email: string;
}
export interface UploadCheckInRequest {
    check_in_uid: string;
    dev_mac: string;
    type: string;
    color?: number;
    nfc_id: string;
    created_time: string;
}
export interface AccessTypesResponse {
    access_types: AccessType[];
}
export interface ValidateAccessQuantityResponse {
    valid: boolean;
    available: number;
    message?: string;
}
export interface TokensResponse {
    tokens: Token[];
}
export interface ValidateTokenQuantityResponse {
    valid: boolean;
    available: number;
    message?: string;
}
export interface PurchaseTicketsWithBalanceRequest {
    event_id: number;
    nfc_id: string;
    tickets: TicketPurchaseItem[];
}
export interface TicketPurchaseItem {
    access_type_uid: string;
    quantity: number;
}
export interface PurchaseTicketsResponse {
    success: boolean;
    transaction?: Transaction;
    transfers?: PATransfer[];
}
export interface RedeemPromotionRequest {
    code: string;
    event_id: number;
    nfc_id: string;
}
export interface RedeemPromotionResponse {
    success: boolean;
    transaction?: Transaction;
    message?: string;
}
export interface SaveBillingInfoRequest {
    event_id: number;
    billing_info: BillingInfo;
}
export interface BillingInfoResponse {
    stripe_billing_info?: BillingInfo;
}
export interface NotificationsResponse {
    notifications: Array<{
        id: number;
        uid: string;
        title: string;
        message: string;
        type: string;
        read: boolean;
        created_time: string;
    }>;
}
export interface LatestVersionResponse {
    version: string;
    version_code: number;
    force_update: boolean;
    message?: string;
    store_url?: string;
}
/**
 * Each item in the reload amounts array from GET /events/{uid}/balances
 * Backend returns a direct JSON array, not wrapped in an object
 */
export interface ReloadAmountItem {
    id: number;
    event_id?: number;
    amount: number;
    promo?: number;
    photo?: string;
    description_en?: string;
    description_es?: string;
    description_pt?: string;
    is_other?: boolean;
    auto_token_number?: number;
    auto_token_quantity?: number;
    auto_token_limit_per_user?: number;
    auto_token_global_limit?: number;
    min_amount_to_reload?: number;
    available_auto_tokens?: boolean;
}
//# sourceMappingURL=types.d.ts.map