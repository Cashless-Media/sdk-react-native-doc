/**
 * Time Utilities
 * Handles date/time formatting for API communication
 * Mirrors Android/iOS TimeHelper functionality
 */
/**
 * Get current time in ISO8601 format
 */
export declare function getCurrentTimeISO(): string;
/**
 * Get current time in ISO8601 format without milliseconds
 */
export declare function getCurrentTimeISONoMs(): string;
/**
 * Parse an ISO8601 string to a Date object
 */
export declare function parseISO(dateString: string): Date | null;
/**
 * Format a Date object to ISO8601 string
 */
export declare function formatToISO(date: Date): string;
/**
 * Get Unix timestamp in seconds
 */
export declare function getUnixTimestamp(): number;
/**
 * Get Unix timestamp in milliseconds
 */
export declare function getUnixTimestampMs(): number;
/**
 * Format date for display (localized)
 */
export declare function formatForDisplay(date: Date | string, format?: string): string;
/**
 * Format date for display (short format)
 */
export declare function formatShortDate(date: Date | string): string;
/**
 * Format time for display
 */
export declare function formatTime(date: Date | string): string;
/**
 * Check if a date is expired (before now)
 */
export declare function isExpired(dateString: string): boolean;
/**
 * Get time difference in human-readable format
 */
export declare function getTimeDifference(dateString: string): string;
/**
 * Add hours to a date
 */
export declare function addHours(date: Date | string, hours: number): Date;
/**
 * Add days to a date
 */
export declare function addDays(date: Date | string, days: number): Date;
/**
 * Check if two dates are the same day
 */
export declare function isSameDay(date1: Date | string, date2: Date | string): boolean;
/**
 * Get start of day
 */
export declare function startOfDay(date: Date | string): Date;
/**
 * Get end of day
 */
export declare function endOfDay(date: Date | string): Date;
//# sourceMappingURL=TimeHelper.d.ts.map