/**
 * Structured Logger for MyCashless SDK
 * Provides controlled logging with debug flag support
 * Consumers can provide a custom log handler for external logging services
 */
export declare enum LogLevel {
    DEBUG = 0,
    INFO = 1,
    WARN = 2,
    ERROR = 3,
    NONE = 4
}
export type LogHandler = (level: LogLevel, tag: string, message: string, data?: unknown) => void;
export declare class Logger {
    private static debugEnabled;
    private static customHandler;
    /**
     * Configure logger — called during SDK initialization
     * @param debug - When true, debug/info/warn messages are logged
     */
    static configure(debug: boolean): void;
    /**
     * Set a custom log handler (e.g., Sentry, Datadog, custom analytics)
     * When set, all log output goes through this handler instead of console
     */
    static setLogHandler(handler: LogHandler | null): void;
    static debug(tag: string, message: string, data?: unknown): void;
    static info(tag: string, message: string, data?: unknown): void;
    static warn(tag: string, message: string, data?: unknown): void;
    /**
     * Error level — ALWAYS logs regardless of debug flag
     */
    static error(tag: string, message: string, data?: unknown): void;
    /**
     * Reset logger state (for testing)
     */
    static reset(): void;
}
//# sourceMappingURL=Logger.d.ts.map