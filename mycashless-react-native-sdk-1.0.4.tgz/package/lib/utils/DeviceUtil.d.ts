/**
 * Device Utilities
 * Handles device identification and ID generation
 * Mirrors Android/iOS DeviceUtil functionality
 */
/**
 * Generate a unique device identifier (12 hex chars).
 * Matches Android DeviceUtil.generateDeviceUDID() and iOS DeviceUtil.generateDeviceUDID():
 *   - 11 hex digits from millisecond timestamp
 *   - 1 hex digit random (0-14)
 * This should be called once and stored persistently.
 */
export declare function generateDeviceUDID(): string;
/**
 * Generate a unique device ID (longer format)
 */
export declare function generateDeviceUniqueId(): string;
/**
 * Generate the MyCashless ID used for chip identification
 * Format: EventID (4 hex chars) + DeviceUDID
 *
 * @param eventId - The current event ID
 * @param deviceUDID - The device's unique identifier
 */
export declare function getMyCashlessId(eventId: number, deviceUDID: string): string;
/**
 * Get the encryption key for ChipData
 * Must be exactly 16 characters for AES
 *
 * @param eventId - The current event ID
 * @param deviceUDID - The device's unique identifier
 */
export declare function getEventDChipId(eventId: number, deviceUDID: string): string;
/**
 * Convert a byte array to a hex string
 */
export declare function byteArrayToHexString(bytes: Uint8Array): string;
/**
 * Convert a hex string to a byte array
 */
export declare function hexStringToByteArray(hex: string): Uint8Array;
/**
 * Generate a unique transaction UID
 */
export declare function generateTransactionUID(): string;
/**
 * Generate a unique transfer UID
 */
export declare function generateTransferUID(): string;
/**
 * Generate a unique check-in UID
 */
export declare function generateCheckInUID(): string;
/**
 * Get the current device platform
 */
export declare function getPlatform(): 'ios' | 'android' | 'web';
/**
 * Get device info string for logging
 */
export declare function getDeviceInfo(): string;
//# sourceMappingURL=DeviceUtil.d.ts.map