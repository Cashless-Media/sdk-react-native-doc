/**
 * useWallet Hook
 * React hook for wallet state management
 */
import type { Transaction, TokenAmount } from '../core/types';
export interface UseWalletResult {
    balance: number;
    promo: number;
    total: number;
    tokens: TokenAmount;
    reload: number;
    firstReloaded: boolean;
    balanceFormatted: string;
    promoFormatted: string;
    totalFormatted: string;
    isLoading: boolean;
    error: string | null;
    refreshWallet: () => Promise<void>;
    getTransactionHistory: () => Promise<Transaction[]>;
    hasSufficientBalance: (amount: number, usePromo?: boolean) => boolean;
}
/**
 * Hook for wallet management
 */
export declare function useWallet(currency?: string): UseWalletResult;
//# sourceMappingURL=useWallet.d.ts.map