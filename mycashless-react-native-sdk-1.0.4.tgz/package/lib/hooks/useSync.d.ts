/**
 * useSync Hook
 * React hook for sync state management
 */
import type { SyncResult } from '../core/types';
export interface UseSyncResult {
    isSyncing: boolean;
    lastSyncTime: Date | null;
    lastSyncResult: SyncResult | null;
    error: string | null;
    syncNow: () => Promise<SyncResult>;
    startAutoSync: () => void;
    stopAutoSync: () => void;
}
/**
 * Hook for sync management
 */
export declare function useSync(): UseSyncResult;
//# sourceMappingURL=useSync.d.ts.map