/**
 * usePayment Hook
 * React hook for payment operations
 */
import type { PaymentIntentResult, SetupIntentResult, SavedPaymentMethod, PayPalOrderResult, MercadoPagoPreferenceResult, MercadoPagoVerifyResult, AvailablePaymentMethods } from '../services/PaymentService';
import type { ReloadAmount, BillingInfo } from '../core/types';
import type { PayPalCaptureOrderResponse } from '../api/types';
export interface UsePaymentResult {
    isLoading: boolean;
    error: string | null;
    paymentMethods: SavedPaymentMethod[];
    reloadAmounts: ReloadAmount[];
    availableMethods: AvailablePaymentMethods | null;
    loadConfig: () => Promise<void>;
    getStripePublishableKey: () => Promise<string>;
    getApplePayMerchantId: () => string;
    createPaymentIntent: (reloadDetail: string, customerId?: string | null, paymentMethodId?: string | null, referralCode?: string) => Promise<PaymentIntentResult | null>;
    confirmPaymentIntent: (paymentIntentId: string) => Promise<boolean>;
    applyReloadToChip: () => Promise<boolean>;
    loadPaymentMethods: () => Promise<void>;
    createSetupIntent: () => Promise<SetupIntentResult | null>;
    deletePaymentMethod: (methodId: string) => Promise<boolean>;
    getBillingInfo: () => Promise<BillingInfo | null>;
    saveBillingInfo: (info: BillingInfo) => Promise<boolean>;
    getPayPalClientId: () => Promise<string | null>;
    createPayPalOrder: (reloadDetail: string, referralCode?: string) => Promise<PayPalOrderResult | null>;
    capturePayPalOrder: (orderId: string, transferIds: number[], tableIds: number[], serviceFee: number) => Promise<PayPalCaptureOrderResponse | null>;
    createMercadoPagoPreference: (reloadDetail: string, referralCode?: string) => Promise<MercadoPagoPreferenceResult | null>;
    verifyMercadoPagoPayment: (externalReference?: string, maxRetries?: number) => Promise<MercadoPagoVerifyResult>;
    getMercadoPagoErrorMessage: (statusDetail: string) => string;
    shouldSuggestDifferentMethod: (statusDetail: string) => boolean;
    calculateTotal: (amount: number) => Promise<{
        subtotal: number;
        fee: number;
        total: number;
        feePercent: number;
    }>;
    buildReloadDetail: (amounts: Array<{
        id: number;
        quantity: number;
        is_other?: boolean;
        amount?: number;
    }>) => string;
    formatAmount: (amountInCents: number) => string;
}
/**
 * Hook for payment operations
 */
export declare function usePayment(currency?: string): UsePaymentResult;
//# sourceMappingURL=usePayment.d.ts.map