/**
 * useAuth Hook
 * React hook for authentication state management
 */
import type { User, AuthResult, RegisterData } from '../core/types';
export interface UseAuthResult {
    user: Partial<User> | null;
    isLoggedIn: boolean;
    isLoading: boolean;
    error: string | null;
    login: (phone: string, password: string) => Promise<AuthResult>;
    register: (userData: RegisterData, firebaseToken?: string) => Promise<AuthResult>;
    logout: () => Promise<void>;
    updateUser: (userData: Partial<User>) => Promise<User | null>;
    refreshUser: () => Promise<void>;
    checkPhoneExists: (phone: string) => Promise<boolean>;
}
/**
 * Hook for authentication management
 */
export declare function useAuth(): UseAuthResult;
//# sourceMappingURL=useAuth.d.ts.map