/**
 * MyCashless SDK Type Definitions
 * Mirrors Android/iOS model classes for compatibility
 */
import { TransactionType, TransactionStatus, PaymentType, TransferType, TransferStatusType, EventType, CheckInType } from './constants';
export interface SDKConfig {
    /** Use production API (true) or staging (false) */
    production: boolean;
    /** Stripe publishable key for payments */
    stripePublishableKey?: string;
    /** Default language (en, es, pt) */
    language?: string;
    /** Enable debug logging */
    debug?: boolean;
}
export interface User {
    id: number;
    code: string;
    first_name: string;
    last_name: string;
    email: string;
    email_verified: boolean;
    phone: string;
    phone_verified: boolean;
    gender?: string;
    birthday?: string;
    zipcode?: string;
    city?: string;
    country?: string;
    photo_url?: string;
    complete_profile: boolean;
    age?: number;
    language?: string;
    device_udid?: string;
}
export interface RegisterData {
    phone: string;
    password: string;
    first_name?: string;
    last_name?: string;
    email?: string;
    gender?: string;
    birthday?: string;
}
export interface AuthResult {
    success: boolean;
    user?: User;
    token?: string;
    error?: string;
}
export interface Event {
    id: number;
    uid: string;
    name: string;
    place?: string;
    currency: string;
    currency_code?: string;
    type: EventType;
    image_url?: string;
    logo_url?: string;
    banner_url?: string;
    start_date?: string;
    end_date?: string;
    welcome_message_en?: string;
    welcome_message_es?: string;
    /** Encrypted event option from backend (AES-encrypted with master key) */
    pa_option?: string;
    config?: EventConfig;
}
export interface EventConfig {
    chip_max_balance: number;
    chip_max_promo: number;
    reload_allowed: boolean;
    access_allowed: boolean;
    share_balance: boolean;
    share_tickets: boolean;
    share_tokens: boolean;
    share_promo: boolean;
    is_stripe: boolean;
    is_paypal: boolean;
    is_braintree: boolean;
    is_mercado_pago: boolean;
    is_adyen: boolean;
    is_cash: boolean;
    payment_fee: number;
    cashless_fee: number;
    service_charge_mode: number;
    is_refund: boolean;
    only_onsite_refund: boolean;
    refund_fee_amount: number;
    refund_fee_percent: number;
    refund_max_percent: number;
    refund_min_amount: number;
    refund_max_amount: number;
    refund_hours_limit: number;
    stripe_publishable_key?: string;
    stripe_merchant_id?: string;
}
export interface EventConnection {
    id: number;
    event_id: number;
    user_id: number;
    dchip_id: string;
    status: string;
    balance?: number;
    promo_balance?: number;
    token_detail?: string;
    custom_fields?: string;
    is_complete_info?: number;
}
export interface Transaction {
    id?: number;
    uid: string;
    trans_number?: string;
    event_id: number;
    type: TransactionType;
    payment_type: PaymentType;
    balance: number;
    tip_balance: number;
    transferred_balance: number;
    currency: string;
    tax: number;
    promo: number;
    token_detail: string;
    nfc_id?: string;
    dev_mac?: string;
    operator_name?: string;
    status: TransactionStatus;
    created_time: string;
    is_synced: boolean;
    user_id?: number;
    lat?: number;
    lng?: number;
    note?: string;
}
export interface TransactionCreateParams {
    event_id: number;
    type: TransactionType;
    balance: number;
    promo?: number;
    token_detail?: string;
    payment_type?: PaymentType;
    note?: string;
}
export interface PATransfer {
    id?: number;
    uid: string;
    type: TransferType;
    event_id: number;
    user_id?: number;
    buyer_id?: number;
    balance: number;
    promo_balance: number;
    online_details?: string;
    status: TransferStatusType;
    transaction_ids?: string;
    referral_code?: string;
    access_code?: string;
    ticket_name?: string;
    ticket_color?: number;
    ticket_details?: string;
    create_time?: string;
    update_time?: string;
    confirm_time?: string;
    deposit_time?: string;
    dev_mac?: string;
    dev_name?: string;
    check_in_uid?: string;
    is_synced: boolean;
}
export interface TransferResponse {
    transfer: PATransfer;
    details?: {
        name: string;
        color: number;
        accessDetails?: AccessType;
    };
}
export interface AccessType {
    id: number;
    uid: string;
    name: string;
    description?: string;
    description_es?: string;
    price: number;
    color: number;
    quantity_available?: number;
    quantity_limit?: number;
    personal_limit?: number;
    section?: string;
    row?: string;
    seat?: string;
    folio_number?: string;
    pin?: string;
}
export interface Ticket {
    transfer: PATransfer;
    accessType?: AccessType;
    isUsed: boolean;
    isExpired: boolean;
}
export interface TicketPurchase {
    access_type_uid: string;
    quantity: number;
}
export interface Token {
    id: number;
    uid: string;
    name: string;
    price: number;
    quantity_available?: number;
    quantity_limit?: number;
    personal_limit?: number;
    token_number: number;
}
export interface TokenAmount {
    token1: number;
    token2: number;
    token3: number;
    token4: number;
    token5: number;
}
export interface ChipDataState {
    balance: number;
    reload: number;
    promo: number;
    cnt: number;
    token1: number;
    token2: number;
    token3: number;
    token4: number;
    token5: number;
    firstReloaded: boolean;
    isParent: boolean;
    openCashless: boolean;
    PIN: string;
    expiredDate: number;
}
export interface WalletBalance {
    balance: number;
    promo: number;
    reload: number;
    tokens: TokenAmount;
    firstReloaded: boolean;
}
export interface CheckIn {
    id?: number;
    uid: string;
    event_id: number;
    type: CheckInType;
    dchip_id: string;
    color?: number;
    dev_mac?: string;
    created_time: string;
    is_synced: boolean;
}
export interface PaymentIntent {
    client_secret: string;
    publishable_key: string;
    status: string;
    amount?: number;
    currency?: string;
}
export interface SetupIntent {
    client_secret: string;
    publishable_key: string;
}
export interface PaymentMethod {
    id: string;
    type: string;
    card?: {
        brand: string;
        last4: string;
        exp_month: number;
        exp_year: number;
        country?: string;
    };
}
export interface ReloadAmount {
    id: number;
    amount: number;
    promo?: number;
    description?: string;
    photo?: string;
    is_other?: boolean;
    auto_token_number?: number;
    auto_token_quantity?: number;
    auto_token_global_limit?: number;
    available_auto_tokens?: boolean;
}
export interface BillingInfo {
    line1?: string;
    line2?: string;
    city?: string;
    state?: string;
    postal_code?: string;
    country?: string;
}
export interface SyncResult {
    success: boolean;
    transactionsSynced: number;
    transfersSynced: number;
    checkInsSynced: number;
    errors: string[];
    timestamp: string;
}
/** Callback invoked when background sync completes after QR processing */
export type SyncStatusCallback = (result: SyncResult) => void;
export interface ApiResponse<T> {
    success: boolean;
    data?: T;
    error?: string;
    statusCode: number;
}
export interface PaginatedResponse<T> {
    items: T[];
    total: number;
    page: number;
    per_page: number;
}
export interface Notification {
    id: number;
    event_id: number;
    picture: string;
    title: string;
    summary_text: string;
    text: string;
    is_read: boolean;
    is_redeemed: boolean;
    token_number: number;
    token_amount: number;
    promo_amount: number;
    created_at: string;
    event_uid: string;
    logo_url: string;
}
export interface ParentData {
    id?: number;
    event_id: number;
    user_id: number;
    dchip_id: string;
    name: string;
    phone: string;
    area_name: string;
    operator_name: string;
    operator_device: string;
    created_time: string;
    is_synced: boolean;
}
export interface DepositTicket {
    uid: string;
    name: string;
    count: number;
    selectedCount: number;
    isSelected: boolean;
    transferUids: string[];
}
export interface ShareResult {
    success: boolean;
    transfer?: PATransfer;
    link?: string;
    error?: string;
}
export interface InviteValidation {
    valid: boolean;
    transfer?: PATransfer;
    error?: string;
}
/**
 * Parsed fields from an mPOS transaction QR code.
 * 13-16 pipe-delimited fields, AES-encrypted with eventOption.
 *
 * Format (from mPOS QRUtil.getTransactionQRCode):
 * EventID|TransactionUID|TransNumber|Type|PaymentType|Status|Balance|Promo|TokenDetail|NfcID|DevMac|OperatorName|Timestamp|TipBalance|TransferredBalance|Note
 */
export interface ParsedTransactionQR {
    eventId: number;
    transactionUid: string;
    transactionNumber: string;
    /** TransactionType: 1=BALANCE, 2=SALE, 3=TIP, 4=REFUND, 6=DEPOSIT */
    type: number;
    paymentType: number;
    status: number;
    /** Transaction amount in cents (NOT the new total) */
    balance: number;
    /** Promo amount in cents */
    promo: number;
    tokenDetail: string;
    /** User's dchipId (eventIdHex + deviceUDID) */
    nfcId: string;
    devMac: string;
    operatorName: string;
    timestamp?: string;
    tipBalance?: number;
    transferredBalance?: number;
    note?: string;
}
/**
 * Result returned by MyCashlessSDK.processScannedQR()
 * Status uses QRCodeStatus constants (0=VALID, 1=INVALID, etc.)
 */
export interface ProcessQRResult {
    /** QRCodeStatus value */
    status: number;
    /** Human-readable message */
    message: string;
    /** Kind of QR detected */
    qrType?: 'transaction' | 'personal' | 'fastpass' | 'unknown';
    /** TransactionType from the QR (1=BALANCE, 2=SALE, etc.) */
    transactionType?: number;
    /** Transaction amount applied in cents */
    amount?: number;
    /** Promo amount applied in cents */
    promoAmount?: number;
    /** The Transaction object created in local DB */
    transaction?: Transaction;
    /** Updated wallet balance after processing */
    newBalance?: WalletBalance;
    /** Raw parsed QR data (for debugging / advanced use) */
    parsedData?: ParsedTransactionQR;
}
//# sourceMappingURL=types.d.ts.map