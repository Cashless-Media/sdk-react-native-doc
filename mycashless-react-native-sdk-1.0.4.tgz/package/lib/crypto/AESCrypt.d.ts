/**
 * AES Encryption Utilities
 * Implements AES-256-CBC encryption with fixed IV for legacy compatibility
 * Mirrors Android AESCrypt.java and iOS Crypto.swift
 *
 * IMPORTANT: Uses a fixed IV ("1234567890123456") for backwards compatibility
 * with existing Android/iOS encrypted data. This is a known security trade-off.
 */
/**
 * AES encryption/decryption utility class
 * Compatible with Android/iOS implementations
 */
export declare class AESCrypt {
    /**
     * Fixed IV for legacy compatibility
     * Matches Android/iOS implementations
     */
    private static readonly LEGACY_IV;
    /**
     * Encrypt plaintext using AES-256-CBC
     *
     * @param password - The encryption key (will be padded/truncated to 16 chars)
     * @param plaintext - The text to encrypt
     * @returns Base64 encoded ciphertext
     */
    static encrypt(password: string, plaintext: string): string;
    /**
     * Decrypt ciphertext using AES-256-CBC
     *
     * @param password - The decryption key (will be padded/truncated to 16 chars)
     * @param ciphertext - Base64 encoded ciphertext
     * @returns Decrypted plaintext
     */
    static decrypt(password: string, ciphertext: string): string;
    /**
     * Generate AES key from password
     * Uses raw password bytes directly for legacy compatibility
     *
     * Note: This is NOT a secure key derivation method.
     * It's maintained for backwards compatibility with Android/iOS implementations.
     *
     * @param password - The password string
     * @returns CryptoJS WordArray key
     */
    private static generateKey;
    /**
     * Encrypt bytes to Base64 string
     * Used for ChipData encryption
     *
     * @param password - The encryption key
     * @param bytes - Byte array to encrypt
     * @returns Base64 encoded ciphertext
     */
    static encryptBytes(password: string, bytes: Uint8Array): string;
    /**
     * Decrypt Base64 string to bytes
     * Used for ChipData decryption
     *
     * @param password - The decryption key
     * @param ciphertext - Base64 encoded ciphertext
     * @returns Decrypted byte array
     */
    static decryptToBytes(password: string, ciphertext: string): Uint8Array | null;
    /**
     * Generate a random encryption key
     * For new installations that don't need legacy compatibility
     */
    static generateRandomKey(): string;
    /**
     * Hash a string using SHA-256
     */
    static sha256(input: string): string;
    /**
     * Hash a string using MD5
     * Used for some legacy operations
     */
    static md5(input: string): string;
}
//# sourceMappingURL=AESCrypt.d.ts.map