/**
 * ChipData - Encrypted Wallet Management
 * Handles the 24-byte encrypted wallet state
 * Mirrors Android ChipData.java and iOS ChipData.swift
 *
 * Binary Format (24 bytes):
 * Bytes 0-3:   balance      (4 bytes, big-endian int32, in cents)
 * Bytes 4-7:   reload       (4 bytes, big-endian int32, in cents)
 * Bytes 8-10:  promo        (3 bytes, big-endian, 24-bit value, in cents)
 * Byte 11:     cnt          (1 byte, transaction counter)
 * Bytes 12-16: token1-5     (5 bytes, 1 byte each, max 255 each)
 * Byte 17:     firstReloaded (1 byte boolean, 0=false, 1=true)
 * Byte 18:     isParent     (1 byte boolean)
 * Byte 19:     openCashless (1 byte boolean)
 * Bytes 20-21: PIN          (2 bytes, 12-bit value: (byte20 & 0x0F) << 8 + byte21)
 * Bytes 22-23: expiredDate  (2 bytes, big-endian uint16)
 */
import type { ChipDataState, Transaction, TokenAmount } from '../core/types';
/**
 * ChipData class - Singleton pattern for wallet state management
 */
export declare class ChipData {
    private static instance;
    private state;
    private eventId;
    private deviceUDID;
    private getStorageValue;
    private setStorageValue;
    private getTransactionsFromDB;
    private constructor();
    /**
     * Get the singleton instance
     */
    static getInstance(): ChipData;
    /**
     * Initialize ChipData with required dependencies
     */
    initialize(eventId: number, deviceUDID: string, getStorage: (key: string) => Promise<string | null>, setStorage: (key: string, value: string) => Promise<void>, getTransactions: () => Promise<Transaction[]>): void;
    /**
     * Create an empty wallet state
     */
    private createEmptyState;
    /**
     * Load encrypted chip data from storage
     */
    loadData(): Promise<boolean>;
    /**
     * Save chip data to encrypted storage
     */
    saveData(): Promise<boolean>;
    /**
     * Parse 24-byte array into ChipDataState
     */
    private parseFromBytes;
    /**
     * Encode ChipDataState to 24-byte array
     */
    private encodeToBytes;
    /**
     * Update wallet state based on a transaction
     * Handles all 12 transaction types with proper +/- logic
     *
     * @param transaction - The transaction to apply
     * @param canceled - Whether this is a cancellation (reverse the operation)
     */
    updateByTransaction(transaction: Transaction, canceled?: boolean): void;
    /**
     * Parse a timestamp string that may be epoch ms or ISO date
     */
    private parseTimestamp;
    /**
     * Restore wallet state from all transactions in the database
     * Used after logout/session expiry to rebuild state
     */
    restoreFromDB(): Promise<boolean>;
    /**
     * Clear all wallet data
     */
    clear(): void;
    /**
     * Get current wallet state (read-only copy)
     */
    getState(): ChipDataState;
    /**
     * Set wallet state directly (use with caution)
     */
    setState(newState: Partial<ChipDataState>): void;
    /**
     * Get total token count
     */
    getTokenCount(): number;
    /**
     * Get tokens as TokenAmount object
     */
    getTokens(): TokenAmount;
    /**
     * Parse token_detail JSON string to TokenAmount
     */
    parseTokenDetail(tokenDetail: string | undefined): TokenAmount;
    /**
     * Add tokens to current state
     */
    private addTokens;
    /**
     * Subtract tokens from current state
     */
    private subtractTokens;
    /**
     * Check if wallet has sufficient balance for a purchase
     */
    hasSufficientBalance(amount: number, usePromo?: boolean): boolean;
    /**
     * Calculate how much balance and promo to use for a purchase
     */
    calculatePaymentBreakdown(amount: number): {
        balance: number;
        promo: number;
    };
    /**
     * Update event context (when switching events)
     */
    setEventContext(eventId: number, deviceUDID: string): void;
    /**
     * Reset singleton instance (for testing)
     */
    static resetInstance(): void;
}
//# sourceMappingURL=ChipData.d.ts.map