/**
 * Sync Service
 * Background synchronization of transactions, transfers, and check-ins
 * Mirrors Android ServiceWorker and iOS SyncService
 */
import type { SyncResult, Transaction } from '../core/types';
/**
 * SyncService class
 * Handles periodic background synchronization
 */
export declare class SyncService {
    private static instance;
    private apiClient;
    private dbManager;
    private chipData;
    private syncInterval;
    private isSyncing;
    private isSyncingTransactions;
    private isSyncingReload;
    private isSyncingAccess;
    private isSyncingCheckIns;
    private onSyncComplete?;
    private onSyncError?;
    private constructor();
    /**
     * Get singleton instance
     */
    static getInstance(): SyncService;
    /**
     * Set sync callbacks
     */
    setCallbacks(onComplete?: (result: SyncResult) => void, onError?: (error: string) => void): void;
    /**
     * Start periodic sync (every 5 minutes)
     */
    startPeriodicSync(): void;
    /**
     * Stop periodic sync
     */
    stopPeriodicSync(): void;
    /**
     * Check if sync is running
     */
    isSyncRunning(): boolean;
    /**
     * Trigger immediate sync
     */
    syncNow(): Promise<SyncResult>;
    /**
     * Sync transactions to server
     */
    private syncTransactions;
    /**
     * Download active balance transfers from the backend and apply them to
     * the local wallet. Equivalent to iOS SyncService.syncReloadTransfer and
     * Android TransferRepository.useReloadTransactions.
     *
     * Returns the canonical Transaction list created by the backend so callers
     * (e.g. WalletService.syncOnlineReloads) can show them in the UI immediately.
     */
    syncReloadTransfers(eventUid?: string): Promise<{
        synced: number;
        transactions: Transaction[];
        error?: string;
    }>;
    /**
     * Sync access (ticket) transfers with conflict resolution
     */
    private syncAccessTransfers;
    /**
     * Sync used transfer status to server
     */
    private syncUsedTransfers;
    /**
     * Upload DChip device info
     */
    private uploadDChipInfo;
    /**
     * Sync check-ins to server
     */
    private syncCheckIns;
    /**
     * Get last sync time
     */
    getLastSyncTime(): Promise<string | null>;
    /**
     * Reset singleton (for testing)
     */
    static resetInstance(): void;
}
//# sourceMappingURL=SyncService.d.ts.map