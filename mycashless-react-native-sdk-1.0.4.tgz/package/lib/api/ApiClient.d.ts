/**
 * API Client
 * HTTP client with authentication and error handling
 * Mirrors Android ApiClient and iOS ApiClient
 */
import { AxiosInstance } from 'axios';
declare module 'axios' {
    interface InternalAxiosRequestConfig {
        _retried?: boolean;
    }
}
import type { ApiResponse } from './types';
/**
 * API Client configuration
 */
export interface ApiClientConfig {
    production: boolean;
    language?: string;
    onSessionExpired?: () => void;
    onAuthError?: (error: string) => void;
}
/**
 * ApiClient class
 * Singleton HTTP client with interceptors
 */
export declare class ApiClient {
    private static instance;
    private client;
    private config;
    private token;
    private constructor();
    /**
     * Get singleton instance
     */
    static getInstance(config?: ApiClientConfig): ApiClient;
    /**
     * Initialize or reinitialize with new config
     */
    static initialize(config: ApiClientConfig): ApiClient;
    /**
     * Setup request and response interceptors
     */
    private setupInterceptors;
    /**
     * Handle 401 authentication errors
     * Mirrors Android TokenAuthenticator behavior
     * Only runs once to prevent cascade clearing on multiple 401s
     */
    private isHandlingAuthError;
    private handleAuthError;
    /**
     * Set auth token
     */
    setAuthToken(token: string): void;
    /**
     * Clear auth token
     */
    clearAuthToken(): void;
    /**
     * Get current auth token
     */
    getAuthToken(): string | null;
    /**
     * Set language
     */
    setLanguage(language: string): void;
    /**
     * Make a GET request
     */
    get<T>(endpoint: string, params?: Record<string, unknown>, requiresAuth?: boolean): Promise<ApiResponse<T>>;
    /**
     * Make a POST request
     */
    post<T>(endpoint: string, data?: unknown, requiresAuth?: boolean): Promise<ApiResponse<T>>;
    /**
     * Make a PUT request
     */
    put<T>(endpoint: string, data?: unknown, requiresAuth?: boolean): Promise<ApiResponse<T>>;
    /**
     * Make a DELETE request
     */
    delete<T>(endpoint: string, data?: unknown, requiresAuth?: boolean): Promise<ApiResponse<T>>;
    /**
     * Generic request method
     */
    request<T>(method: 'GET' | 'POST' | 'PUT' | 'DELETE', endpoint: string, data?: unknown, params?: Record<string, unknown>, requiresAuth?: boolean): Promise<ApiResponse<T>>;
    /**
     * Handle request errors
     */
    private handleError;
    /**
     * Extract error message from response body
     * Matches Android ApiClient.getError() pattern
     */
    private extractErrorMessage;
    /**
     * Create a new client for refund service (different base URL)
     */
    getRefundClient(): AxiosInstance;
    /**
     * Make request to refund service
     */
    refundRequest<T>(method: 'GET' | 'POST', endpoint: string, data?: unknown): Promise<ApiResponse<T>>;
    /**
     * Reset singleton (for testing)
     */
    static resetInstance(): void;
    /**
     * Get the underlying axios instance (for advanced usage)
     */
    getAxiosInstance(): AxiosInstance;
}
//# sourceMappingURL=ApiClient.d.ts.map