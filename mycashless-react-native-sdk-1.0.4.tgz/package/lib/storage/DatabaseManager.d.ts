/**
 * Database Manager
 * SQLite wrapper for local data persistence
 * Mirrors Android DBManager and iOS SQLiteHelper
 */
import type { Transaction, PATransfer, Event, CheckIn, Notification, ParentData, DepositTicket } from '../core/types';
/**
 * Database adapter interface
 * Implementations can use react-native-sqlite-storage or expo-sqlite
 */
export interface DatabaseAdapter {
    executeSql(sql: string, params?: unknown[]): Promise<DatabaseResult>;
    transaction(callback: (tx: DatabaseTransaction) => void): Promise<void>;
    close(): Promise<void>;
}
export interface DatabaseTransaction {
    executeSql(sql: string, params?: unknown[]): Promise<DatabaseResult>;
}
export interface DatabaseResult {
    rows: {
        length: number;
        item(index: number): Record<string, unknown>;
        raw(): Record<string, unknown>[];
    };
    insertId?: number;
    rowsAffected: number;
}
/**
 * In-memory database adapter (for testing)
 */
export declare class MemoryDatabaseAdapter implements DatabaseAdapter {
    private tables;
    executeSql(sql: string, _params?: unknown[]): Promise<DatabaseResult>;
    transaction(callback: (tx: DatabaseTransaction) => void): Promise<void>;
    close(): Promise<void>;
}
/**
 * DatabaseManager class
 * Provides CRUD operations for all local tables
 */
export declare class DatabaseManager {
    private static instance;
    private adapter;
    private initialized;
    private constructor();
    /**
     * Get singleton instance
     */
    static getInstance(): DatabaseManager;
    /**
     * Initialize database with adapter
     */
    initialize(adapter: DatabaseAdapter): Promise<void>;
    /**
     * Check if initialized
     */
    isInitialized(): boolean;
    /**
     * Add a new transaction
     */
    addTransaction(tx: Transaction): Promise<boolean>;
    /**
     * Update an existing transaction
     */
    updateTransaction(tx: Transaction): Promise<boolean>;
    /**
     * Get all transactions for current event
     */
    getTransactions(eventId: number): Promise<Transaction[]>;
    /**
     * Get unsynced transactions (limit for batching)
     */
    getTransactionsToSync(eventId: number, limit?: number): Promise<Transaction[]>;
    /**
     * Mark transaction as synced
     */
    markTransactionSynced(uid: string): Promise<boolean>;
    /**
     * Get transaction by UID
     */
    getTransactionByUid(uid: string): Promise<Transaction | null>;
    private mapRowsToTransactions;
    /**
     * Add a new transfer
     */
    addTransfer(transfer: PATransfer): Promise<boolean>;
    /**
     * Update an existing transfer
     */
    updateTransfer(transfer: PATransfer): Promise<boolean>;
    /**
     * Get transfer by UID
     */
    getTransferByUid(uid: string): Promise<PATransfer | null>;
    /**
     * Get all transfers for event
     */
    getTransfers(eventId: number): Promise<PATransfer[]>;
    /**
     * Get active ticket transfers (type=ACCESS, status=ACTIVE or DEPOSIT)
     */
    getActiveTickets(eventId: number): Promise<PATransfer[]>;
    /**
     * Get used ticket count
     */
    getUsedTicketCount(eventId: number): Promise<number>;
    /**
     * Get transfers to sync (used but not synced)
     */
    getTransfersToSync(eventId: number): Promise<PATransfer[]>;
    /**
     * Mark transfer as synced
     */
    markTransferSynced(uid: string): Promise<boolean>;
    /**
     * Delete transfer by UID
     */
    deleteTransfer(uid: string): Promise<boolean>;
    private mapRowsToTransfers;
    /**
     * Add a check-in record
     */
    addCheckIn(checkIn: CheckIn): Promise<boolean>;
    /**
     * Get check-ins to sync
     */
    getCheckInsToSync(eventId: number): Promise<CheckIn[]>;
    /**
     * Mark check-in as synced
     */
    markCheckInSynced(uid: string): Promise<boolean>;
    private mapRowsToCheckIns;
    /**
     * Add or update event
     */
    saveEvent(event: Event): Promise<boolean>;
    /**
     * Get event by ID
     */
    getEventById(id: number): Promise<Event | null>;
    private mapRowToEvent;
    /**
     * Clear all data for an event
     */
    clearEventData(eventId: number): Promise<void>;
    /**
     * Clear all data
     */
    clearAllData(): Promise<void>;
    /**
     * Get transaction by trans_number (matches Android getTransactionByTransId)
     */
    getTransactionByTransNumber(eventId: number, transNumber: string): Promise<Transaction | null>;
    /**
     * Cancel a transaction (matches iOS cancelTransaction)
     */
    cancelTransaction(uid: string): Promise<boolean>;
    /**
     * Set location to a transaction (matches iOS setLocationToTransaction)
     */
    setTransactionLocation(uid: string, lat: number, lng: number): Promise<boolean>;
    /**
     * Reset all transactions to unsynced (matches Android syncTransactionsAgain)
     */
    syncTransactionsAgain(eventId: number): Promise<boolean>;
    /**
     * Assign user_id to transactions that have user_id=0
     * (matches Android/iOS addUserIdToTransactions)
     */
    addUserIdToTransactions(userId: number): Promise<boolean>;
    /**
     * Get today's total tip balance for sale transactions
     * (matches Android/iOS getTodayTotalTipBalance)
     */
    getTodayTotalTipBalance(eventId: number, userId: number, todayStartISO: string): Promise<number>;
    /**
     * Get today's total sale balance (balance - tip_balance)
     * (matches Android/iOS getTodayTotalSaleBalance)
     */
    getTodayTotalSaleBalance(eventId: number, userId: number, todayStartISO: string): Promise<number>;
    /**
     * Get total reload balance (BALANCE + TRANSFER ADDED + DEPOSIT ADDED)
     * (matches Android/iOS getTotalReloadBalance)
     */
    getTotalReloadBalance(eventId: number, userId: number): Promise<number>;
    /**
     * Get total sale balance (SALE + TIP + TRANSFER REMOVED + DEPOSIT REMOVED + DONATION + REFUND)
     * (matches Android/iOS getTotalSaleBalance)
     */
    getTotalSaleBalance(eventId: number, userId: number): Promise<number>;
    /**
     * Get transfers grouped by online_details (matches Android getPATransferMap)
     */
    getTransferMap(eventId: number, userId: number): Promise<Map<string, PATransfer[]>>;
    /**
     * Get deposit tickets grouped by access type
     * (matches Android/iOS getDepositTickets)
     */
    getDepositTickets(eventId: number, userId: number): Promise<DepositTicket[]>;
    /**
     * Get transfers by multiple UIDs (matches Android getPATransfersByUids)
     */
    getTransfersByUids(uids: string[]): Promise<PATransfer[]>;
    /**
     * Get distinct used access ticket colors (matches Android/iOS getAccessColors)
     */
    getAccessColors(eventId: number, userId: number): Promise<number[]>;
    /**
     * Get first used access transfer matching given colors
     * (matches Android getAccessTransferByColors / iOS getAccessTransfer)
     */
    getAccessTransferByColors(eventId: number, userId: number, colors: number[]): Promise<PATransfer | null>;
    /**
     * Get deposit ticket transfers by colors
     * (matches Android getDepositTicketTransfersByColors)
     */
    getDepositTransfersByColors(eventId: number, userId: number, colors: number[]): Promise<PATransfer[]>;
    /**
     * Get count of active (DEPOSIT) access transfers
     * (matches Android/iOS getActiveAccessTransferCount)
     */
    getActiveAccessTransferCount(eventId: number, userId: number): Promise<number>;
    /**
     * Redeem a transfer (set status=USED with confirm data)
     * (matches iOS redeemPATransfer)
     */
    redeemTransfer(id: number, confirmTime: string, devMac: string, devName: string, checkInUid: string): Promise<boolean>;
    /**
     * Mark transfer as used (status only)
     * (matches iOS markAsUsedPATransfer)
     */
    markTransferAsUsed(id: number): Promise<boolean>;
    /**
     * Update transfer ticket color (matches iOS updatePATransferColor)
     */
    updateTransferColor(id: number, color: number): Promise<boolean>;
    /**
     * Update transfer ticket details (matches iOS updatePATransferDetails)
     */
    updateTransferDetails(id: number, details: string): Promise<boolean>;
    /**
     * Delete transfer by ID (matches Android deleteTransfer(PATransfer))
     */
    deleteTransferById(id: number): Promise<boolean>;
    /**
     * Get all events (matches Android/iOS getEvents)
     */
    getEvents(): Promise<Event[]>;
    /**
     * Add a notification (matches Android/iOS addNotification)
     */
    addNotification(notification: Notification): Promise<boolean>;
    /**
     * Update a notification (matches Android/iOS updateNotification)
     */
    updateNotification(notification: Notification): Promise<boolean>;
    /**
     * Get all notifications (matches Android/iOS getNotifications)
     */
    getNotifications(): Promise<Notification[]>;
    /**
     * Get notification ID list (matches Android/iOS getNotificationIDList)
     */
    getNotificationIDList(): Promise<number[]>;
    /**
     * Get unread notification count (matches Android/iOS getUnreadNotificationCount)
     */
    getUnreadNotificationCount(): Promise<number>;
    private mapRowsToNotifications;
    /**
     * Add parent data (matches Android/iOS addParentData)
     */
    addParentData(parentData: ParentData): Promise<boolean>;
    /**
     * Get parent data for current event/user/device
     * (matches Android/iOS getParentData)
     */
    getParentData(eventId: number, userId: number, dchipId: string): Promise<ParentData | null>;
    /**
     * Update a check-in (matches Android updateCheckIn)
     */
    updateCheckIn(checkIn: CheckIn): Promise<boolean>;
    /**
     * Delete a check-in by ID (matches Android deleteCheckIn)
     */
    deleteCheckIn(id: number): Promise<boolean>;
    /**
     * Clear a specific table (matches Android clearTable)
     */
    clearTable(tableName: string): Promise<boolean>;
    /**
     * Drop a specific table (matches Android dropTable)
     */
    dropTable(tableName: string): Promise<boolean>;
    /**
     * Close database connection
     */
    close(): Promise<void>;
    /**
     * Reset singleton (for testing)
     */
    static resetInstance(): void;
}
//# sourceMappingURL=DatabaseManager.d.ts.map