/**
 * Secure Storage Interface
 * Abstracts encrypted key-value storage for sensitive data
 * Supports both react-native-keychain and expo-secure-store
 */
/**
 * Storage adapter interface
 * Implementations can use react-native-keychain, expo-secure-store, or AsyncStorage
 */
export interface StorageAdapter {
    getItem(key: string): Promise<string | null>;
    setItem(key: string, value: string): Promise<void>;
    removeItem(key: string): Promise<void>;
    clear(): Promise<void>;
}
/**
 * In-memory storage adapter (for testing or fallback)
 */
export declare class MemoryStorageAdapter implements StorageAdapter {
    private storage;
    getItem(key: string): Promise<string | null>;
    setItem(key: string, value: string): Promise<void>;
    removeItem(key: string): Promise<void>;
    clear(): Promise<void>;
}
/**
 * SecureStorage class
 * Provides a unified interface for secure data storage
 */
export declare class SecureStorage {
    private static adapter;
    private static initialized;
    /**
     * Initialize with a storage adapter
     * Call this during SDK initialization with the appropriate adapter
     *
     * @example
     * // With react-native-keychain
     * import * as Keychain from 'react-native-keychain';
     * SecureStorage.initialize(new KeychainAdapter());
     *
     * @example
     * // With expo-secure-store
     * import * as SecureStore from 'expo-secure-store';
     * SecureStorage.initialize(new ExpoSecureStoreAdapter());
     */
    static initialize(adapter: StorageAdapter): void;
    /**
     * Check if storage is initialized
     */
    static isInitialized(): boolean;
    /**
     * Store a value securely
     */
    static setSecure(key: string, value: string): Promise<void>;
    /**
     * Retrieve a value securely
     */
    static getSecure(key: string): Promise<string | null>;
    /**
     * Remove a value
     */
    static removeSecure(key: string): Promise<void>;
    /**
     * Clear all stored values
     */
    static clearAll(): Promise<void>;
    /**
     * Store a JSON object securely
     */
    static setSecureJSON<T>(key: string, value: T): Promise<void>;
    /**
     * Retrieve a JSON object securely
     */
    static getSecureJSON<T>(key: string): Promise<T | null>;
    /**
     * Check if a key exists
     */
    static hasKey(key: string): Promise<boolean>;
    /**
     * Get adapter for direct access (advanced usage)
     */
    static getAdapter(): StorageAdapter;
    /**
     * Reset to memory adapter (for testing)
     */
    static resetToMemory(): void;
}
/**
 * Example adapter for react-native-keychain
 * Users should create this in their app and pass to SecureStorage.initialize()
 *
 * @example
 * import * as Keychain from 'react-native-keychain';
 *
 * class KeychainAdapter implements StorageAdapter {
 *   private readonly SERVICE = 'com.mycashless.sdk';
 *
 *   async getItem(key: string): Promise<string | null> {
 *     try {
 *       const result = await Keychain.getGenericPassword({ service: `${this.SERVICE}.${key}` });
 *       return result ? result.password : null;
 *     } catch {
 *       return null;
 *     }
 *   }
 *
 *   async setItem(key: string, value: string): Promise<void> {
 *     await Keychain.setGenericPassword(key, value, { service: `${this.SERVICE}.${key}` });
 *   }
 *
 *   async removeItem(key: string): Promise<void> {
 *     await Keychain.resetGenericPassword({ service: `${this.SERVICE}.${key}` });
 *   }
 *
 *   async clear(): Promise<void> {
 *     // Note: Keychain doesn't have a bulk clear, would need to track keys
 *   }
 * }
 */
/**
 * Example adapter for expo-secure-store
 *
 * @example
 * import * as ExpoSecureStore from 'expo-secure-store';
 *
 * class ExpoSecureStoreAdapter implements StorageAdapter {
 *   async getItem(key: string): Promise<string | null> {
 *     return await ExpoSecureStore.getItemAsync(key);
 *   }
 *
 *   async setItem(key: string, value: string): Promise<void> {
 *     await ExpoSecureStore.setItemAsync(key, value);
 *   }
 *
 *   async removeItem(key: string): Promise<void> {
 *     await ExpoSecureStore.deleteItemAsync(key);
 *   }
 *
 *   async clear(): Promise<void> {
 *     // Expo SecureStore doesn't have bulk clear
 *   }
 * }
 */
/**
 * Example adapter for AsyncStorage (less secure, but works everywhere)
 *
 * @example
 * import AsyncStorage from '@react-native-async-storage/async-storage';
 *
 * class AsyncStorageAdapter implements StorageAdapter {
 *   private readonly PREFIX = '@mycashless:';
 *
 *   async getItem(key: string): Promise<string | null> {
 *     return await AsyncStorage.getItem(this.PREFIX + key);
 *   }
 *
 *   async setItem(key: string, value: string): Promise<void> {
 *     await AsyncStorage.setItem(this.PREFIX + key, value);
 *   }
 *
 *   async removeItem(key: string): Promise<void> {
 *     await AsyncStorage.removeItem(this.PREFIX + key);
 *   }
 *
 *   async clear(): Promise<void> {
 *     const keys = await AsyncStorage.getAllKeys();
 *     const sdkKeys = keys.filter(k => k.startsWith(this.PREFIX));
 *     await AsyncStorage.multiRemove(sdkKeys);
 *   }
 * }
 */
//# sourceMappingURL=SecureStorage.d.ts.map