/**
 * Cached Data Manager
 * In-memory cache with persistence layer
 * Mirrors Android CachedData.java and iOS CachedData.swift
 */
import { StorageAdapter } from './SecureStorage';
import type { User, Event, EventConfig } from '../core/types';
/**
 * CachedData class
 * Provides typed access to cached values with persistence
 */
export declare class CachedData {
    private static memoryCache;
    private static adapter;
    private static initialized;
    /**
     * Initialize with a storage adapter
     */
    static initialize(adapter: StorageAdapter): Promise<void>;
    /**
     * Load critical values into memory for fast access
     */
    private static loadCriticalValues;
    /**
     * Check if initialized
     */
    static isInitialized(): boolean;
    static getString(key: string, defaultValue?: string): Promise<string>;
    static setString(key: string, value: string): Promise<void>;
    static getInt(key: string, defaultValue?: number): Promise<number>;
    static setInt(key: string, value: number): Promise<void>;
    static getFloat(key: string, defaultValue?: number): Promise<number>;
    static setFloat(key: string, value: number): Promise<void>;
    static getBoolean(key: string, defaultValue?: boolean): Promise<boolean>;
    static setBoolean(key: string, value: boolean): Promise<void>;
    static getJSON<T>(key: string): Promise<T | null>;
    static setJSON<T>(key: string, value: T): Promise<void>;
    static remove(key: string): Promise<void>;
    static clearAll(): Promise<void>;
    static getToken(): Promise<string>;
    static setToken(token: string): Promise<void>;
    static clearToken(): Promise<void>;
    static isLoggedIn(): Promise<boolean>;
    static getUserId(): Promise<number>;
    static setUserInfo(user: User): Promise<void>;
    static getUserInfo(): Promise<Partial<User>>;
    static clearUserInfo(): Promise<void>;
    static getDeviceUDID(): Promise<string>;
    static setDeviceUDID(udid: string): Promise<void>;
    static getFCMToken(): Promise<string>;
    static setFCMToken(token: string): Promise<void>;
    static getEventId(): Promise<number>;
    static getEventUid(): Promise<string>;
    static setEventInfo(event: Event): Promise<void>;
    static setEventConfig(config: EventConfig): Promise<void>;
    static getEventConfig(): Promise<Partial<EventConfig>>;
    static clearEventInfo(): Promise<void>;
    static setSessionExpired(expired: boolean): Promise<void>;
    static isSessionExpired(): Promise<boolean>;
    static getLanguage(): Promise<string>;
    static setLanguage(language: string): Promise<void>;
    static getLastSyncTime(): Promise<string>;
    static setLastSyncTime(time: string): Promise<void>;
    static getFromMemory(key: string): unknown | undefined;
    static setInMemory(key: string, value: unknown): void;
    /**
     * Reset for testing
     */
    static reset(): void;
    /**
     * Get the main reload type for the current event
     * @returns Main reload type (0-7)
     */
    static getMainReloadType(): Promise<number>;
    /**
     * Set the main reload type for the current event
     */
    static setMainReloadType(type: number): Promise<void>;
    /**
     * Check if the main page should be Balance/Reload
     */
    static isMainPageBalance(): Promise<boolean>;
    /**
     * Check if the main page should be Product/Marketplace
     */
    static isMainPageProduct(): Promise<boolean>;
    /**
     * Check if the main page should be Table
     */
    static isMainPageTable(): Promise<boolean>;
    /**
     * Check if the main page should be Ticket/Access
     */
    static isMainPageTicket(): Promise<boolean>;
    /**
     * Check if the main page should be Delivery
     */
    static isMainPageDelivery(): Promise<boolean>;
    /**
     * Check if the main page should be Pickup
     */
    static isMainPagePickup(): Promise<boolean>;
    /**
     * Check if the main page should be Activate Chip
     */
    static isMainPageActivateChip(): Promise<boolean>;
    /**
     * Check if user is in incognito mode (not logged in)
     */
    static isIncognitoMode(): Promise<boolean>;
    /**
     * Check if any payment method is available
     */
    static isPayAvailable(): Promise<boolean>;
    /**
     * Check if online reload is available
     */
    static isOnlineReloadAvailable(): Promise<boolean>;
    /**
     * Get full username (first + last name)
     */
    static getUsername(): Promise<string>;
    /**
     * Get string array from storage
     */
    static getArray(key: string): Promise<string[]>;
    /**
     * Set string array to storage
     */
    static setArray(key: string, array: string[]): Promise<void>;
    /**
     * Get double/number array from storage
     */
    static getDoubleArray(key: string): Promise<number[]>;
    /**
     * Set double/number array to storage
     */
    static setDoubleArray(key: string, array: number[]): Promise<void>;
    /**
     * Get boolean array from storage
     */
    static getBooleanArray(key: string): Promise<boolean[]>;
    /**
     * Set boolean array to storage
     */
    static setBooleanArray(key: string, array: boolean[]): Promise<void>;
    /**
     * Get DChip banner list
     */
    static getDChipBannerList(): Promise<string[]>;
    /**
     * Set DChip banner list
     */
    static setDChipBannerList(banners: string[]): Promise<void>;
    /**
     * Get available refund methods
     */
    static getAvailableRefundMethods(): Promise<{
        paypal: boolean;
        venmo: boolean;
        usBank: boolean;
        nonUsBank: boolean;
        debitCard: boolean;
        savingsAccount: boolean;
        currentAccount: boolean;
        brazilBank: boolean;
        iban: boolean;
        cci: boolean;
    }>;
    /**
     * Get ticket access code
     */
    static getTicketAccessCode(): Promise<string>;
    /**
     * Set ticket access code
     */
    static setTicketAccessCode(code: string): Promise<void>;
    /**
     * Get referral code
     */
    static getReferralCode(): Promise<string>;
    /**
     * Set referral code
     */
    static setReferralCode(code: string): Promise<void>;
    /**
     * Get unread notification count
     */
    static getUnreadNotificationCount(): Promise<number>;
    /**
     * Set unread notification count
     */
    static setUnreadNotificationCount(count: number): Promise<void>;
    /**
     * Get transaction count (for rating prompt)
     */
    static getTransactionCount(): Promise<number>;
    /**
     * Increment transaction count
     */
    static incrementTransactionCount(): Promise<void>;
    /**
     * Check if user has rated the app
     */
    static hasRated(): Promise<boolean>;
    /**
     * Set app as rated
     */
    static setRated(rated: boolean): Promise<void>;
}
//# sourceMappingURL=CachedData.d.ts.map