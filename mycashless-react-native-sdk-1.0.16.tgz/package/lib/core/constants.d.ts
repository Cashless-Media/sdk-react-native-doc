/**
 * MyCashless SDK Constants
 * Mirrors Android/iOS app constants for compatibility
 */
export declare const API_URLS: {
    readonly PRODUCTION: "https://paapi.mycashless.com";
    readonly STAGING: "https://api-staging-pa-q52bzbziea-uc.a.run.app";
    readonly REFUND_PRODUCTION: "https://admin-backend-hqtvybvuja-uc.a.run.app";
    readonly REFUND_STAGING: "https://admin-backend-q52bzbziea-uc.a.run.app";
    readonly FRONTEND_PRODUCTION: "https://mycashless.com/account/e";
    readonly FRONTEND_STAGING: "https://dev.mycashless.com/account/e";
};
export declare const API_VERSION = "/api/v2.0";
export declare const API_VERSION_V3 = "/api/v3.0";
export declare enum TransactionType {
    BALANCE = 1,
    SALE = 2,
    TIP = 3,
    REFUND = 4,
    TRANSFER = 5,
    DEPOSIT = 6,
    RUNNER = 7,
    REFERENCE = 8,
    DONATION = 9,
    RESET_BALANCE = 10,
    REDEEM = 11,
    TICKET_SALE = 12
}
export declare enum TransactionStatus {
    CREATED = 1,
    PREPARING = 2,
    READY = 3,
    ONTHEWAY = 4,
    ARRIVED = 5,
    DELIVERED = 6,
    CANCELED = 7,
    ASSIGNED = 8,
    REMOVED = 9,
    ADDED = 10,
    INCOMPLETE = 11,
    INCIDENT = 12
}
export declare const DchipTransactionStatus: {
    readonly CREATED: 1;
    readonly CANCELED: 7;
    readonly REMOVED: 9;
    readonly ADDED: 10;
    readonly INCOMPLETE: 11;
    readonly INCIDENT: 12;
};
export declare enum PaymentType {
    NONE = 0,
    DEBIT_CARD = 1,
    CASH = 2,
    MIX = 3,
    PA = 4,// Personal Account
    NFC = 5,
    DCHIP = 6,
    CREDIT_CARD = 7,
    OTHER = 8
}
export declare enum TransferType {
    BALANCE = 0,
    EXPRESS = 1,
    TABLE = 2,
    APP = 3,
    ACCESS = 4
}
export declare const TransferStatus: {
    readonly ACTIVE: "ACTIVE";
    readonly MERGED: "MERGED";
    readonly USED: "USED";
    readonly CANCELED: "CANCELED";
    readonly DEPOSIT: "DEPOSIT";
    readonly UNPAID: "UNPAID";
    readonly EXPIRED: "EXPIRED";
    readonly SHARING: "SHARING";
};
export type TransferStatusType = typeof TransferStatus[keyof typeof TransferStatus];
export declare enum EventType {
    CASHLESS = "CASHLESS",
    GUESTLIST = "GUESTLIST",
    MARKETPLACE = "MARKETPLACE",
    OTHER = "OTHER"
}
export declare enum CheckInType {
    CHECK_IN = "CHECK_IN",
    CHECK_OUT = "CHECK_OUT"
}
export declare const SYNC_CONFIG: {
    readonly INTERVAL_MS: number;
    readonly TRANSACTION_BATCH_SIZE: 10;
    readonly API_TIMEOUT_MS: number;
};
export declare const CHIP_LIMITS: {
    readonly MAX_BALANCE: number;
    readonly MAX_PROMO: number;
    readonly MAX_TOKEN_VALUE: 255;
    readonly DATA_SIZE_BYTES: 24;
};
export declare const AES_CONFIG: {
    readonly LEGACY_IV: "1234567890123456";
    readonly KEY_LENGTH: 16;
    readonly ALGORITHM: "AES";
    readonly MODE: "CBC";
    readonly PADDING: "Pkcs7";
    /** Master key for decrypting event pa_option (matches Android DeviceUtil.getOption()) */
    readonly PA_OPTION_KEY: "UjXn2r5u8x!A%D*G";
};
export declare const STRIPE_KEYS: {
    readonly MX_PROD: "pk_live_k7kTSVOzabeHtymqsE8sBrD2";
    readonly MX_DEV: "pk_test_o7g2Z3CW5gdCPTQFirbJFGex";
    readonly US_PROD: "pk_live_E6MWUSlTESrf8YLeVyr0vZ5900fkbgqpks";
    readonly US_DEV: "pk_test_gK7Pf97jPxfaWDRGqIgxVZLS00OAeJ80Z4";
    readonly APPLE_PAY_MERCHANT_ID: "merchant.com.mycashless";
};
export declare const TEST_EVENT_IDS: readonly number[];
export declare const DEFAULTS: {
    readonly TRANS_NUMBER: "000000000";
    readonly DEV_MAC: "00:00:00:00:00:00";
    readonly OPERATOR_NAME: "mycashless";
    readonly LANGUAGE: "es";
};
export declare const LEGAL_URLS: {
    readonly TERMS_OF_SERVICE: "https://mycashless.com/terms-and-conditions/";
    readonly PRIVACY_POLICY: "https://mycashless.com/privacy-policy/";
};
export declare const Gender: {
    readonly MALE: "Male";
    readonly FEMALE: "Female";
    readonly OTHER: "Other";
};
export declare const VerificationType: {
    readonly REGISTER: "register";
    readonly RESET_PASSWORD: "reset_password";
    readonly INVITE: "Invite";
};
export declare const VerificationMethod: {
    readonly SMS: "sms";
    readonly WHATSAPP: "whatsapp";
};
export declare const VerifyAction: {
    readonly CONFIRM: "confirm";
    readonly CANCEL: "cancel";
    readonly RESEND: "resend";
};
export declare const QRCodeType: {
    readonly TRANSACTION: "Transaction";
    readonly ACCESS: "Access";
    readonly LOCATION_BASED_CHECK_IN: "Location";
    readonly CHECK_IN: "CheckIn";
    readonly CHECK_OUT: "CheckOut";
    readonly ACTIVITY: "Activity";
    readonly KIDS: "Kids";
};
export declare const QRCodeStatus: {
    readonly VALID: 0;
    readonly INVALID: 1;
    readonly INVALID_ENCRYPT: 2;
    readonly INVALID_EVENT: 3;
    readonly INVALID_ID: 4;
    readonly INVALID_TRANSACTION: 5;
    readonly INVALID_USED: 6;
    readonly INVALID_NO_EXIST: 7;
    readonly INVALID_BALANCE: 8;
    readonly INVALID_TYPE: 9;
};
export declare const DChipQRCodeType: {
    readonly PERSONAL_QR: 0;
    readonly BALANCE: 1;
    readonly EXPRESS: 2;
    readonly TICKET: 3;
    readonly TABLE: 4;
    readonly DCHIP_ACCESS: 5;
    readonly ANONYMOUS_TICKET: 6;
    readonly CHECK_IN: 7;
    readonly CHECK_OUT: 8;
    readonly PARENT: 9;
};
export declare const PurchaseType: {
    readonly PURCHASE_BALANCE: "PURCHASE_BALANCE";
    readonly PURCHASE_TICKET: "PURCHASE_TICKET";
    readonly PURCHASE_TOKEN: "PURCHASE_TOKEN";
};
export declare const CheckoutPaymentType: {
    readonly NONE: 0;
    readonly NATIVE_PAY: 1;
    readonly CARD: 2;
    readonly PAYPAL: 3;
    readonly CASH: 4;
};
export declare const PaymentStatus: {
    readonly PAID: 0;
    readonly UNPAID: 1;
};
export declare const AutoTipType: {
    readonly TIP_OFF: 0;
    readonly TIP_10_PERCENT: 1;
    readonly TIP_15_PERCENT: 2;
    readonly TIP_20_PERCENT: 3;
    readonly TIP_OTHER: 4;
};
export declare const EventReloadStatus: {
    readonly NOT_STARTED: -1;
    readonly VALID: 0;
    readonly ENDED: 1;
};
export declare const SyncServiceCommand: {
    readonly DOWNLOAD_EVENT: "download_event";
    readonly DOWNLOAD_PRELOAD: "download_preload";
    readonly DOWNLOAD_ACCESS: "download_access";
};
export declare const SyncCommand: {
    readonly SYNC_EVENT: "SYNC_EVENT";
    readonly SYNC_TRANSFERS: "SYNC_TRANSFERS";
    readonly SYNC_TRANSACTIONS: "SYNC_TRANSACTIONS";
    readonly SYNC_TRANSACTIONS_AGAIN: "SYNC_TRANSACTIONS_AGAIN";
};
export declare const SyncTransactionStatus: {
    readonly FAILED: 0;
    readonly EXECUTION_LIMIT: 1;
    readonly SUCCESS: 2;
};
export declare const CacheServiceCommand: {
    readonly EVENT_UPDATE: "event_update";
    readonly TICKETS_UPDATE: "tickets_update";
};
export declare const AppIcon: {
    readonly DEFAULT: 0;
    readonly OFFICIAL: 1;
    readonly MR_BUNNY: 2;
    readonly FUTURE: 3;
    readonly FORMULA_2025: 4;
};
export declare const IconEventUID: {
    readonly OFFICIAL: "08d32052903d4e6db4a0ff9a60f2119a";
    readonly MR_BUNNY: "343072dabafc4bdba534405a97d884ab";
    readonly FUTURE: "36d96b0d18a046efa46603764e25c15a";
    readonly FORMULA_2025: "b7ea8ecaa31142d1bf5e24a908a0c92f";
};
export declare const NotificationAction: {
    readonly UNREAD_NOTIFICATION: "UNREAD_NOTIFICATION";
};
export declare const RATING_CONFIG: {
    readonly RATING_REVIEW: 4;
    readonly TRANSACTION_RATING_COUNT: 2;
};
export declare const RETRY_CONFIG: {
    readonly TRANSACTION_UPLOAD: 3;
};
export declare const TIMING: {
    readonly BTN_COUNT_TIME_MS: 3000;
    readonly DAY_TIME_STAMP_MS: number;
    readonly SYNC_TRANSACTION_API_EXECUTION_LIMIT: 5000;
};
export declare const DCHIP_CONFIG: {
    readonly MAX_SCAN_AGAIN: 1;
    readonly SPLIT_PAY_CHIP_ID: "SPLIT_PAYMENT";
};
export declare const STRIPE_AUTO_REFUND_WORKFLOW = 1;
export declare const EventTypeInt: {
    readonly CASHLESS: 0;
    readonly GUESTLIST: 1;
    readonly MARKETPLACE: 2;
    readonly OTHER: 3;
};
export declare const MainReloadType: {
    readonly BALANCE: 0;
    readonly PRODUCT: 1;
    readonly TABLE: 2;
    readonly TICKET: 4;
    readonly DELIVERY: 5;
    readonly PICKUP: 6;
    readonly ACTIVATE_CHIP: 7;
};
export declare const StorageKeys: {
    readonly DEVICE_UNIQUE_ID: "device_unique_id";
    readonly DEVICE_UDID: "device_udid";
    readonly DEVICE_DCHIP_ID: "dchip_id";
    readonly FCM_TOKEN: "fcm_token";
    readonly FIREBASE_VERIFICATION_ID: "firebase_verification_id";
    readonly TOKEN: "token";
    readonly USER_ID: "user_id";
    readonly USER_LOGGED_IN: "user_logged_in";
    readonly SESSION_EXPIRED: "session_expired";
    readonly CHECK_SESSION_EXPIRED: "check_session_expired";
    readonly EVENT_LOGIN_SUGGESTED: "event_login_suggested";
    readonly USER_CODE: "user_code";
    readonly USER_FIRST_NAME: "user_first_name";
    readonly USER_LAST_NAME: "user_last_name";
    readonly USER_EMAIL: "user_email";
    readonly USER_EMAIL_VERIFIED: "user_email_verified";
    readonly USER_PHONE: "user_phone";
    readonly USER_PHONE_VERIFIED: "user_phone_verified";
    readonly USER_BIRTHDAY: "user_birthday";
    readonly USER_GENDER: "user_gender";
    readonly USER_PHOTO: "user_photo";
    readonly USER_COMPLETE_PROFILE: "user_complete_profile";
    readonly EVENT_ID: "event_id";
    readonly EVENT_UID: "event_uid";
    readonly CURRENT_EVENT_UID: "current_event_uid";
    readonly EVENT_NAME: "event_name";
    readonly EVENT_PLACE: "event_place";
    readonly EVENT_IMAGE: "event_image";
    readonly EVENT_LOGO: "event_logo";
    readonly EVENT_CURRENCY: "event_currency";
    readonly EVENT_CURRENCY_MARK: "event_currency_mark";
    readonly EVENT_TYPE: "event_type";
    readonly EVENT_OPTION: "event_option";
    readonly EVENT_DATE: "event_date";
    readonly EVENT_DATE_START: "date_start";
    readonly EVENT_DATE_END: "date_end";
    readonly EVENT_TIMEZONE: "timezone";
    readonly EVENT_START_RELOAD: "start_pre";
    readonly EVENT_END_RELOAD: "end_pre";
    readonly EVENT_COUNTRY_NAME: "event_country_name";
    readonly EVENT_COUNTRY_CODE: "event_country_code";
    readonly EVENT_WELCOME_EN: "event_welcome_en";
    readonly EVENT_WELCOME_ES: "event_welcome_es";
    readonly EVENT_RULES_EN: "rules_en";
    readonly EVENT_RULES_ES: "rules_es";
    readonly EVENT_RULES_PT: "rules_pt";
    readonly EVENT_DCHIP_BANNER: "dchip_banner";
    readonly DCHIP_BANNER_LIST: "dchip_banner_list";
    readonly EVENT_DCHIP_BANNERS_WITH_LINK: "dchip_banners_with_link";
    readonly PERSONALIZED_TEXT_COLOR: "personalized_text_color";
    readonly PERSONALIZED_BG_COLOR: "personalized_bg_color";
    readonly CHIP_MAX_BALANCE: "chip_max_balance";
    readonly CHIP_MAX_PROMO: "chip_max_promo";
    readonly EVENT_RELOAD_ALLOWED: "event_reload_allowed";
    readonly EVENT_ACCESS_ALLOWED: "event_access_allowed";
    readonly EVENT_SHARE_BALANCE: "share_balance";
    readonly EVENT_SHARE_TICKETS: "share_tickets";
    readonly EVENT_SHARE_TOKENS: "share_tokens";
    readonly EVENT_SHARE_PROMO: "share_promo";
    readonly MAIN_RELOAD_TYPE: "main_reload_type";
    readonly PA_USER_CUSTOM_FIELDS: "pa_custom_fields";
    readonly IS_COMPLETE_INFO: "is_complete_info";
    readonly PA_POLICY_URL: "pa_policy_url";
    readonly IS_PA_TOKEN: "is_pa_token";
    readonly PROFILE_FULL_NAME: "profile_full_name";
    readonly PROFILE_EMAIL: "profile_email";
    readonly PROFILE_GENDER: "profile_gender";
    readonly PROFILE_BIRTHDAY: "profile_birthday";
    readonly SERVICE_CHARGE_MODE: "service_charge_mode";
    readonly PAYMENT_FEE: "payment_fee";
    readonly CASHLESS_FEE: "cashless_fee";
    readonly PAYMENT_TICKET_FEE: "payment_ticketing_fee";
    readonly CASHLESS_TICKET_FEE: "cashless_ticketing_fee";
    readonly RECEIPT_EMAIL: "receipt_email";
    readonly PA_CURRENCY: "pa_currency";
    readonly PAYMENT_CURRENCY: "payment_currency";
    readonly CURRENCY_RATE: "currency_rate";
    readonly IS_REFUND: "is_refund";
    readonly ONLY_ONSITE_REFUND: "only_onsite_refund";
    readonly REFUND_FEE_AMOUNT: "refund_fee_amount";
    readonly REFUND_FEE_PERCENT: "refund_fee_percent";
    readonly ALLOW_REFUND_LIMIT_TO_ONLINE: "allow_refund_rule_to_online";
    readonly RESTRICT_REFUND_HOURS: "restrict_refund_hours";
    readonly REFUND_MAXIMUM_ENABLED: "refund_max_enabled";
    readonly REFUND_MAX_PERCENT: "refund_max_percent";
    readonly REFUND_MAX_AMOUNT: "refund_max_amount";
    readonly REFUND_MIN_CONSUME_ENABLED: "refund_min_consume_enabled";
    readonly REFUND_MIN_CONSUME_PERCENT: "refund_min_consume_percent";
    readonly REFUND_MIN_CONSUME_AMOUNT: "refund_min_consume_amount";
    readonly REFUND_MIN_AMOUNT: "refund_min_amount";
    readonly REFUND_HOURS_LIMIT: "refund_hours_limit";
    readonly INITIAL_RR: "initial_rr";
    readonly FINAL_RR: "final_rr";
    readonly INITIAL_RP: "initial_rp";
    readonly FINAL_RP: "final_rp";
    readonly REFUND_PAYPAL: "refund_paypal";
    readonly REFUND_VENMO: "refund_venmo";
    readonly REFUND_US_BANK: "refund_us_bank";
    readonly REFUND_NON_US_BANK: "refund_non_us_bank";
    readonly REFUND_DEBIT_CARD: "refund_debit_card";
    readonly REFUND_SAVINGS_ACCOUNT: "refund_savings_account";
    readonly REFUND_CURRENT_ACCOUNT: "refund_current_account";
    readonly REFUND_BRAZIL_BANK: "refund_brazil_bank";
    readonly REFUND_IBAN: "refund_iban";
    readonly REFUND_CCI: "refund_cci";
    readonly IS_INVOICE: "is_invoice";
    readonly IS_ENDED: "is_ended";
    readonly NOT_ACTIVATED: "not_activated";
    readonly DONATION_ORGANIZATION_NAME: "donation_organization_name";
    readonly IS_STRIPE: "is_stripe";
    readonly IS_PAYPAL: "is_paypal";
    readonly IS_BRAINTREE: "is_braintree";
    readonly IS_MERCADO_PAGO: "is_mercado_pago";
    readonly IS_ADYEN: "is_adyen";
    readonly IS_CASH: "is_cash";
    readonly STRIPE_PUBLISHABLE_KEY: "stripe_publishable_key";
    readonly STRIPE_MERCHANT_ID: "stripe_merchant_id";
    readonly PREDEFINED_TIP: "predefined_tip";
    readonly AUTO_TIP: "auto_tip";
    readonly IS_OPEN_VOUCHER: "is_open_voucher";
    readonly IS_LINK_CARD_SELECTED: "is_link_card_selected";
    readonly LINK_CARD_DEFAULT_AMOUNT: "link_card_default_amount";
    readonly DCHIP_SCAN_CNT: "dchip_scan_cnt";
    readonly DCHIP_FORCE_3RD_SCAN: "dchip_force_3rd_scan";
    readonly CHIP_DATA: "ndata";
    readonly TICKET_ACCESS_CODE: "ticket_access_code";
    readonly REDIRECT_ACCESS_VIEW: "redirect_access_view";
    readonly REFERRAL_CODE: "referral_code";
    readonly TICKET_INVITED_QR: "ticket_invited_qr";
    readonly TRANSFER_INVITED_QR: "transfer_invited_qr";
    readonly INVITED_USER_CODE: "invited_user_code";
    readonly EVENT_UID_FOR_ACCESS_REFERRAL: "event_uid_for_access_referral";
    readonly UNREAD_NOTIFICATION: "unread_notification";
    readonly TRANSACTION_COUNT: "transaction_count";
    readonly RATED: "rated";
    readonly RATE_NOT_NOW_TIME: "rate_not_now_time";
    readonly READ_TOUR: "read_tour";
    readonly LATEST_VERSION: "latest_version";
    readonly HIDE_CONFIRMATION: "hide_confirmation";
    readonly LAST_QR_CODE: "last_qr_code";
    readonly SCREEN_BRIGHTNESS: "screen_brightness";
    readonly APP_ICON: "app_icon";
    readonly OPEN_APP_SETTING: "open_app_setting";
    readonly DEEP_LINK_EVENT_UID: "deep_link_event_uid";
    readonly DEEP_LINK_GROUP_NICK_NAME: "deep_link_group_nick_name";
    readonly LANGUAGE: "language";
    readonly INCOGNITO_MODE: "incognito_mode";
    readonly LAST_SYNC_TIME: "last_sync_time";
    readonly USER_ID_ADDED: "user_id_added";
    readonly MY_ACCESS: "my_access";
};
export declare const DB_CONFIG: {
    readonly NAME: "mycashless.db";
    readonly VERSION: 17;
};
export declare const TableNames: {
    readonly TRANSACTION: "\"Transaction\"";
    readonly PA_TRANSFER: "PATransfer";
    readonly EVENT: "Event";
    readonly CHECK_IN: "CheckIn";
    readonly NOTIFICATION: "Notification";
    readonly PARENT_DATA: "ParentData";
};
//# sourceMappingURL=constants.d.ts.map